﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Repository;
using Crud_Operations_Basics.Utils;
using System.Reflection;

namespace Crud_Operations_Basics.Extensions
{
    public static class ServiceExtensions
    {
        public static void ConfigureCors(this IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy", builder =>
                {
                    builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader();
                });
            });
        }

        public static void AddApplicationLayer(this IServiceCollection services)
        {
            services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));
			services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));
        }
        public static void CongigureSQLConnection(this IServiceCollection services, IConfiguration configuration) =>
            services.AddSqlServer<ApplicationDbContext>(configuration.GetConnectionString("DatabaseConnection"));
    }
}

