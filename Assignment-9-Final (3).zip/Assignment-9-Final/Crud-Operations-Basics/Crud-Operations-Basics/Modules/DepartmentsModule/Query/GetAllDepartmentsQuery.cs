﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Query
{
    public class GetAllDepartmentsQuery : IRequest<List<DepartmentModel>> { }

    public class GetAllDepartmentsQueryHandler : IRequestHandler<GetAllDepartmentsQuery, List<DepartmentModel>>
    {
        private readonly IGenericRepository<DepartmentModel> _departmentservice;

        public GetAllDepartmentsQueryHandler(IGenericRepository<DepartmentModel> departmentservice)
        {
            _departmentservice = departmentservice;
        }
        public async Task<List<DepartmentModel>> Handle(GetAllDepartmentsQuery request, CancellationToken cancellationToken)
        {
            return await _departmentservice.GetAllAsync();
        }
    }
}
