﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Query
{
    public class GetDepartmentByIdQuery : IRequest<DepartmentModel>
    {
        public int Id { get; set; }
    }

    public class GetDepartmentByIdQueryHandler : IRequestHandler <GetDepartmentByIdQuery, DepartmentModel>
    {
        private readonly IGenericRepository<DepartmentModel> _genericRepository;

        public GetDepartmentByIdQueryHandler(IGenericRepository<DepartmentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<DepartmentModel> Handle(GetDepartmentByIdQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetByIdAsync(request.Id);
        }
    }

}
