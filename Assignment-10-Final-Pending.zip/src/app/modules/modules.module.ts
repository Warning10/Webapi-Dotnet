import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeModule } from './employee/employee.module';
import { ReactiveFormsModule } from '@angular/forms';
import { DepartmentModule } from './department/department.module';



@NgModule({
  declarations: [
    
  ],
  imports: [
    CommonModule,
    EmployeeModule,
    DepartmentModule,
    ReactiveFormsModule
  ],
  exports: [
    EmployeeModule,
    DepartmentModule
  
  ],
  
})
export class ModulesModule { }
