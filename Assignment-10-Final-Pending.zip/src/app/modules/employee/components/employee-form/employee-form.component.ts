import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DepartmentDataService } from '../../../department/services/department-data.service';
import { IEmployee } from '../../interfaces/employee';
import { EmployeeDataService } from '../../services/employee-data.service';

@Component({
  selector: 'app-employee-form',
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.css']
})
export class EmployeeFormComponent implements OnInit {
  employeeForm: FormGroup;
  designation: string[] = [];
  employeeId: number | null = null;
  isEdit = false;

  constructor(
    private formBuilder: FormBuilder,
    private employeeService: EmployeeDataService,
    private departmentService: DepartmentDataService,
    private router: Router,
    private route: ActivatedRoute,
    private toastr: ToastrService
  ) {
    this.employeeForm = this.formBuilder.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      gender: ['', [Validators.required]],
      phone: ['', [Validators.required]],
      address: ['', [Validators.required]],
      designation: ['', [Validators.required]],
    });
  }

  ngOnInit(): void {
    this.employeeId = +this.route.snapshot.params['id'];
    if (this.employeeId) {
      this.isEdit = true;
      this.employeeService.getEmployee(this.employeeId).subscribe((result) => {
        this.employeeForm.patchValue({
          name: result.name,
          email: result.email,
          gender: result.gender,
          phone: result.phone,
          address: result.address,
          designation: result.designation // Patch the designation
        });
      });
    }

    this.departmentService.getAllDepartment().subscribe((departments) => {
      this.designation = departments.map((department) => department.deptName);
    });
  }

  save(): void {
    if (this.employeeForm.invalid) return;

    const employee: IEmployee = {
      name: this.employeeForm.value.name!,
      email: this.employeeForm.value.email!,
      gender: this.employeeForm.value.gender!,
      phone: this.employeeForm.value.phone!,
      address: this.employeeForm.value.address!,
      designation: this.employeeForm.value.designation!,
    };

    if (this.isEdit) {
      this.employeeService.updateEmployee(this.employeeId!, employee).subscribe(() => {
        this.toastr.success('Employee updated successfully', 'Success');
        this.router.navigate(['/employee-list']);
      }, error => {
        this.toastr.error('Failed to update employee', 'Error');
        console.error('Update failed', error);
      });
    } else {
      this.employeeService.createEmployee(employee).subscribe(() => {
        this.toastr.success('Employee created successfully', 'Success');
        this.router.navigate(['/employee-list']);
      }, error => {
        this.toastr.error('Failed to create employee', 'Error');
        console.error('Creation failed', error);
      });
    }
  }
}
