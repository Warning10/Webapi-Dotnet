import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';
import { EmployeeFormComponent } from './components/employee-form/employee-form.component';
import { EmployeeDataService } from './services/employee-data.service';
import { ToastrModule } from 'ngx-toastr';
import { ReactiveFormsModule } from '@angular/forms'; // Import ReactiveFormsModule here



@NgModule({
  declarations: [
    EmployeeListComponent,
    EmployeeFormComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    ToastrModule.forRoot()
    
  ],
  providers: [
    EmployeeDataService
  ],
  exports: [
    EmployeeListComponent,
    EmployeeFormComponent
  ]
})
export class EmployeeModule { }
