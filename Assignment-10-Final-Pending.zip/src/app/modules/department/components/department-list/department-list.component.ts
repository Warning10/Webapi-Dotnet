import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { IDepartment } from '../../interfaces/department';
import { DepartmentDataService } from '../../services/department-data.service';
import { Router } from '@angular/router';
import * as bootstrap from 'bootstrap';

@Component({
  selector: 'app-department-list',
  templateUrl: './department-list.component.html',
  styleUrls: ['./department-list.component.css']
})
export class DepartmentListComponent implements OnInit {
  departments: IDepartment[] = [];
  selectedDepartment?: IDepartment;

  constructor(
    private departmentService: DepartmentDataService,
    private toastr: ToastrService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadDepartments();
  }

  loadDepartments(): void {
    this.departmentService.getAllDepartment().subscribe({
      next: (data: IDepartment[]) => {
        this.departments = data;
      },
      error: (err) => {
        this.toastr.error('Failed to load departments', 'Error');
      }
    });
  }

  openViewModal(department: IDepartment): void {
    this.selectedDepartment = department;
    const viewModal = new bootstrap.Modal(document.getElementById('viewModal')!);
    viewModal.show();
  }

  openDeleteModal(department: IDepartment): void {
    this.selectedDepartment = department;
    const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal')!);
    deleteModal.show();
  }

  confirmDelete(): void {
    if (this.selectedDepartment?.deptId) {
      this.departmentService.deleteDepartment(this.selectedDepartment.deptId).subscribe({
        next: () => {
          this.toastr.success('Department deleted successfully', 'Success');
          this.loadDepartments();
        },
        error: (err) => {
          this.toastr.error('Failed to delete department', 'Error');
        }
      });
    }
    const deleteModal = bootstrap.Modal.getInstance(document.getElementById('deleteModal')!);
    deleteModal?.hide();
  }

  editDepartment(id: number): void {
    this.router.navigate([`/department-form/${id}`]);
  }

  navigateToAddDepartment(): void {
    this.router.navigate(['/department-form']);
  }
}
