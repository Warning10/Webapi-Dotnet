import { Injectable } from '@angular/core';
import { IDepartment } from '../interfaces/department';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DepartmentDataService {

  private apiUrl = "https://localhost:7162";

  constructor(private http: HttpClient) { }

  getAllDepartment(): Observable<IDepartment[]> {
    return this.http.get<IDepartment[]>(`${this.apiUrl}/api/DepartmentGenericCqrs/all`);
  }

  createDepartment(department: IDepartment): Observable<IDepartment> {
    return this.http.post<IDepartment>(`${this.apiUrl}/api/DepartmentGenericCqrs/create`, department);
  }

  getDepartment(departmentId: number): Observable<IDepartment> {
    return this.http.get<IDepartment>(`${this.apiUrl}/api/DepartmentGenericCqrs/byid/${departmentId}`);
  }

  updateDepartment(departmentId: number, department: IDepartment): Observable<IDepartment> {
    return this.http.put<IDepartment>(`${this.apiUrl}/api/DepartmentGenericCqrs/update/${departmentId}`, department);
  }

  deleteDepartment(departmentId: number): Observable<IDepartment> {
    return this.http.delete<IDepartment>(`${this.apiUrl}/api/DepartmentGenericCqrs/delete/${departmentId}`);
  }
}

