export interface IDepartment {
    deptId?: number;
    deptName: string;
    created?: string;
    updated?: string;
    
}