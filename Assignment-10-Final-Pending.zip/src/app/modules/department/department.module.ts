import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DepartmentListComponent } from './components/department-list/department-list.component';
import { DepartmentFormComponent } from './components/department-form/department-form.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { DepartmentDataService } from './services/department-data.service';



@NgModule({
  declarations: [
    DepartmentListComponent,
    DepartmentFormComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    ToastrModule.forRoot()
    
  ],
  providers: [
    DepartmentDataService
  ],
  exports: [
    DepartmentListComponent,
    DepartmentFormComponent
  ]
})
export class DepartmentModule { }
