﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Student_Teacher.Migrations
{
    /// <inheritdoc />
    public partial class InitialDatabase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Departments",
                columns: table => new
                {
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DeptName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departments", x => x.DeptId);
                });

            migrationBuilder.CreateTable(
                name: "StudentModel",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EnrollmentDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Grade = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StudentModel", x => x.Id);
                    table.ForeignKey(
                        name: "FK_StudentModel_Departments_DeptId",
                        column: x => x.DeptId,
                        principalTable: "Departments",
                        principalColumn: "DeptId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TeacherModel",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    HireDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Position = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TeacherModel", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TeacherModel_Departments_DeptId",
                        column: x => x.DeptId,
                        principalTable: "Departments",
                        principalColumn: "DeptId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Departments",
                columns: new[] { "DeptId", "Created", "DeptName", "Updated" },
                values: new object[,]
                {
                    { new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3741), "Computer", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3741) },
                    { new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3745), "Mechanical", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3746) },
                    { new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3743), "Information Technology", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3743) },
                    { new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3747), "Civil", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3748) },
                    { new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3749), "Production", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3750) }
                });

            migrationBuilder.InsertData(
                table: "StudentModel",
                columns: new[] { "Id", "Created", "DateOfBirth", "DeptId", "Email", "EnrollmentDate", "FirstName", "Gender", "Grade", "LastName", "Updated" },
                values: new object[,]
                {
                    { new Guid("4ba3cf67-2e93-4160-8c3e-b0e33ed2d6fc"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3348), new DateTime(2015, 5, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "alice.smith@example.com", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3346), "Alice", "Female", "Nursery", "Smith", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3349) },
                    { new Guid("8e3a6f53-2cd8-44f5-99b1-458fb4dc4b52"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3367), new DateTime(2000, 11, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "ethan.davis@example.com", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3367), "Ethan", "Male", "10th", "Davis", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3368) },
                    { new Guid("a2f5a227-47a7-4004-b671-108085eeb833"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3357), new DateTime(2005, 12, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "charlie.williams@example.com", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3357), "Charlie", "Non-Binary", "5th", "Williams", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3358) },
                    { new Guid("ab58d34b-b1b4-4037-a06c-6979ec122599"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3353), new DateTime(2010, 7, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "bob.johnson@example.com", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3353), "Bob", "Male", "1st", "Johnson", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3354) },
                    { new Guid("f80a3bf7-31d8-4741-ba7a-53aa4836dde5"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3362), new DateTime(2002, 3, 9, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "diana.brown@example.com", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3361), "Diana", "Female", "8th", "Brown", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3362) }
                });

            migrationBuilder.InsertData(
                table: "TeacherModel",
                columns: new[] { "Id", "Created", "DeptId", "Email", "FirstName", "Gender", "HireDate", "LastName", "Position", "Updated" },
                values: new object[,]
                {
                    { new Guid("0def361f-182e-40cd-9fcb-dc0d9ffd3fa9"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3639), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "pooja.jadhav@example.com", "Pooja", "Female", new DateTime(2020, 3, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "Jadhav", "English Teacher", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3639) },
                    { new Guid("20a035c8-c6f8-468c-8d7a-313ed810d6b9"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3623), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "amit.deshmukh@example.com", "Amit", "Male", new DateTime(2010, 8, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Deshmukh", "Math Teacher", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3623) },
                    { new Guid("21243d8a-bd9f-4bb6-ac8a-bc0ec9e6d0d8"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3636), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "rajesh.kulkarni@example.com", "Rajesh", "Male", new DateTime(2018, 6, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "Kulkarni", "History Teacher", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3636) },
                    { new Guid("5ad8d7ee-2605-4313-84bb-0933549b1b25"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3626), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "snehal.patil@example.com", "Snehal", "Female", new DateTime(2015, 1, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "Patil", "Science Teacher", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3627) },
                    { new Guid("f809598b-a580-4df8-aee5-244832a9f86d"), new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3642), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "vikram.shinde@example.com", "Vikram", "Male", new DateTime(2022, 11, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Shinde", "Physical Education Teacher", new DateTime(2024, 8, 28, 9, 0, 22, 287, DateTimeKind.Utc).AddTicks(3642) }
                });

            migrationBuilder.CreateIndex(
                name: "IX_StudentModel_DeptId",
                table: "StudentModel",
                column: "DeptId");

            migrationBuilder.CreateIndex(
                name: "IX_TeacherModel_DeptId",
                table: "TeacherModel",
                column: "DeptId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "StudentModel");

            migrationBuilder.DropTable(
                name: "TeacherModel");

            migrationBuilder.DropTable(
                name: "Departments");
        }
    }
}
