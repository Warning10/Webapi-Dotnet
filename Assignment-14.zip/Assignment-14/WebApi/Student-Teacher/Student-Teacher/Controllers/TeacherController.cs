﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Student_Teacher.Modules.TeacherModule.Command;
using Student_Teacher.Modules.TeacherModule.Query;

namespace Student_Teacher.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeacherController : ControllerBase
    {
        private readonly ISender _mediatR;

        public TeacherController(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        [HttpGet("all")]
        public async Task<IActionResult> GetAllTeachers()
        {
            try
            {

                var result = await _mediatR.Send(new GetTeacherQuery());

                if (result == null)
                {
                    return NotFound("No Teachers found.");
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }
        }

        [HttpGet("byid/{id}")]
        public async Task<IActionResult> GetTeacherById([FromRoute] Guid id)
        {
            try
            {
                var result = await _mediatR.Send(new GetTeacherByIdQuery { Id = id });

                if (result == null)
                {
                    return NotFound(new { Message = $"Teacher with ID {id} not found." });
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("create")]
        public async Task<object> CreateTeacher([FromBody] CreateTeacherCommand createTeacherCommand)
        {
            try
            {
                var isSuccess = await _mediatR.Send(createTeacherCommand);
                if (!isSuccess)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the Teacher.");
                }
                else
                {
                    return Ok(new { Message = "Teacher created successfully." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("update/{id}")]
        public async Task<object> UpdateTeacher([FromBody] TeacherCommand teacherCommand, [FromRoute] Guid id)
        {
            try
            {
                var updateTeacherCommand = new UpdateTeacherCommand
                {
                    Id = id,
                    FirstName = teacherCommand.FirstName,
                    LastName = teacherCommand.LastName,
                    Email = teacherCommand.Email,
                    Gender = teacherCommand.Gender,
                    DeptId = teacherCommand .DeptId,
                    HireDate = teacherCommand.HireDate,
                    Position = teacherCommand.Position,
                };


                bool isUpdated = await _mediatR.Send(updateTeacherCommand);
                if (!isUpdated)
                {
                    return NotFound(new { Message = $"Teacher with ID {id} not found." });
                }
                else
                {
                    return Ok(new { Message = "Teacher updated successfully." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("delete/{id}")]
        public async Task<object> DeleteTeacher([FromRoute] Guid id)
        {

            try
            {
                var result = await _mediatR.Send(new DeleteTeacherCommand() { Id = id });
                if (result)
                {
                    return Ok(new { Message = $"Teacher with ID {id} deleted successfully" });
                }
                else
                {
                    return NotFound(new { Message = $"Teacher with ID {id} not found." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
