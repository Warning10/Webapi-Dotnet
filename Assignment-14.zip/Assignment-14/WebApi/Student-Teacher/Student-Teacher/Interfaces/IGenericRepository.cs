﻿namespace Student_Teacher
{
    public interface IGenericRepository<T> where T : class 
    {
        Task<List<T>> GetAllAsync();
        Task<T> GetByIdAsync(Guid id);
        Task<bool> AddAsync(T entity);
        Task<bool> UpdateAsync(Guid Id, T entity);
        Task<bool> DeleteAsync(Guid Id);

    }
}
