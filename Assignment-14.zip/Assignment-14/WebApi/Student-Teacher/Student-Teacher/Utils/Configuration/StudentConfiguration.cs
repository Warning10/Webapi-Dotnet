﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Student_Teacher.Models;

namespace Student_Teacher.Utils.Configuration
{
    public class StudentConfiguration : IEntityTypeConfiguration<StudentModel>
    {
        public void Configure(EntityTypeBuilder<StudentModel> builder)
        {
            builder.HasData(
                new StudentModel
                {
                    Id = Guid.NewGuid(),
                    FirstName = "Alice",
                    LastName = "Smith",
                    Email = "alice.smith@example.com",
                    Gender = "Female",
                    DeptId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), 
                    DateOfBirth = new DateTime(2015, 5, 15),
                    EnrollmentDate = DateTime.UtcNow,
                    Grade = "Nursery",
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow
                },
            new StudentModel
            {
                Id = Guid.NewGuid(),
                FirstName = "Bob",
                LastName = "Johnson",
                Email = "bob.johnson@example.com",
                Gender = "Male",
                DeptId = Guid.Parse("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), 
                DateOfBirth = new DateTime(2010, 7, 22),
                EnrollmentDate = DateTime.UtcNow,
                Grade = "1st",
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            },
            new StudentModel
            {
                Id = Guid.NewGuid(),
                FirstName = "Charlie",
                LastName = "Williams",
                Email = "charlie.williams@example.com",
                Gender = "Non-Binary",
                DeptId = Guid.Parse("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), 
                DateOfBirth = new DateTime(2005, 12, 5),
                EnrollmentDate = DateTime.UtcNow,
                Grade = "5th",
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            },
            new StudentModel
            {
                Id = Guid.NewGuid(),
                FirstName = "Diana",
                LastName = "Brown",
                Email = "diana.brown@example.com",
                Gender = "Female",
                DeptId = Guid.Parse("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), 
                DateOfBirth = new DateTime(2002, 3, 9),
                EnrollmentDate = DateTime.UtcNow,
                Grade = "8th",
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            },
            new StudentModel
            {
                Id = Guid.NewGuid(),
                FirstName = "Ethan",
                LastName = "Davis",
                Email = "ethan.davis@example.com",
                Gender = "Male",
                DeptId = Guid.Parse("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), 
                DateOfBirth = new DateTime(2000, 11, 30),
                EnrollmentDate = DateTime.UtcNow,
                Grade = "10th",
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            }
                );
        }
    }
}
