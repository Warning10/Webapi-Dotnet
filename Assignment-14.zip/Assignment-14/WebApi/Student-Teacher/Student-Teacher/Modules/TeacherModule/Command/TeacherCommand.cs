﻿using MediatR;

namespace Student_Teacher.Modules.TeacherModule.Command
{
    public class TeacherCommand : IRequest<bool>
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string Gender { get; set; }

        public Guid DeptId { get; set; }

        public DateTime HireDate { get; set; }

        public string Position { get; set; }
    }
}
