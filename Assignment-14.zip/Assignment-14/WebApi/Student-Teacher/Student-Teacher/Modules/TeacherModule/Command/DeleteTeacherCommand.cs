﻿using FluentValidation.Results;
using MediatR;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.TeacherModule.Command
{
    public class DeleteTeacherCommand : TeacherCommand
    {
        public Guid Id { get; set; }
    }
    public class DeleteTeacherCommandHandler : IRequestHandler<DeleteTeacherCommand, bool>
    {
        private readonly IGenericRepository<TeacherModel> _genericRepository;

        public DeleteTeacherCommandHandler(IGenericRepository<TeacherModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(DeleteTeacherCommand request, CancellationToken cancellationToken)
        {
            var existingTeacher = await _genericRepository.GetByIdAsync(request.Id);
            if (existingTeacher == null)
            {
                return false;
            }
            return await _genericRepository.DeleteAsync(request.Id);
        }

    }

}
