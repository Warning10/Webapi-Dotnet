﻿using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.StudentModule.Command
{
    public class DeleteStudentCommand : StudentCommand
    {
        public Guid Id { get; set; }
    }
    public class DeleteStudentCommandHandler : IRequestHandler<DeleteStudentCommand, bool>
    {
        private readonly IGenericRepository<StudentModel> _genericRepository;

        public DeleteStudentCommandHandler(IGenericRepository<StudentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(DeleteStudentCommand request, CancellationToken cancellationToken)
        {
            var existingStudent = await _genericRepository.GetByIdAsync(request.Id);
            if (existingStudent == null)
            {
                return false;
            }
            return await _genericRepository.DeleteAsync(request.Id);
        }

    }

}
