﻿using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.StudentModule.Command
{
    public class UpdateStudentCommand : StudentCommand
    {
        public Guid Id { get; set; }
    }

    public class UpdateStudentCommandHandler : IRequestHandler<UpdateStudentCommand, bool>
    {
        private readonly IGenericRepository<StudentModel> _genericRepository;


        public UpdateStudentCommandHandler(IGenericRepository<StudentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(UpdateStudentCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new StudentCommandValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }

            var student = new StudentModel
            {
                Id = request.Id,
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Gender = request.Gender,
                DeptId = request.DeptId,
                DateOfBirth = request.DateOfBirth,
                EnrollmentDate = request.EnrollmentDate,
                Grade = request.Grade,
                Updated = DateTime.Now,
            };

            return await _genericRepository.UpdateAsync(request.Id, student);
        }
    }
}

