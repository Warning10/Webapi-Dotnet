﻿using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.StudentModule.Command
{
    public class CreateStudentCommand : StudentCommand { }

    public class CreateStudentCommandHandler : IRequestHandler<CreateStudentCommand, bool>
    {
        private readonly IGenericRepository<StudentModel> _genericRepository;

        public CreateStudentCommandHandler(IGenericRepository<StudentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(CreateStudentCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new StudentCommandValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }
            var studentModel = new StudentModel
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Gender = request.Gender,
                DeptId = request.DeptId,
                DateOfBirth = request.DateOfBirth,
                EnrollmentDate = request.EnrollmentDate,
                Grade = request.Grade,
                Created = DateTime.Now,
                Updated = DateTime.Now,
            };
            return await _genericRepository.AddAsync(studentModel);
        }
    }
}
