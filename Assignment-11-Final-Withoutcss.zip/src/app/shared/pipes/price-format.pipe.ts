import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'priceFormat'
})
export class PriceFormatPipe implements PipeTransform {
     
    transform(value: any): string {
        if(value === null || value === undefined || value === ''){
        return '-';
        }
        return value.toFixed(2);
    }

}
