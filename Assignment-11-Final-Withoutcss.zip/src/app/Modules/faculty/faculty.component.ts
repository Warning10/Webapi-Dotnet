import { Component } from "@angular/core";

@Component({
    selector: 'faculty',
    templateUrl: './faculty.component.html',
    styleUrls: ['./faculty-one.component.css', './faculty-two.component.css']
})
export class FacultyComponent{}