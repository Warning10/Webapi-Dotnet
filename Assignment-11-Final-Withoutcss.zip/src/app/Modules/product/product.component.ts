import { Component } from "@angular/core";

@Component({
    selector: 'product',
    templateUrl: './product.component.html',
    styleUrls: ['./product.component.css']
})
export class ProductComponent {
    isLoggedIn = false;

  toggleLogin() {
    this.isLoggedIn = !this.isLoggedIn;
  }
  items = ['Item 1', 'Item 2', 'Item 3', 'Item 4'];

  product = {
    name: 'Smartphone',
    price: 699.99,
    releaseDate: new Date('2023-08-15T10:00:00'),
    stock: 1250
  };

  products = [
    { name: 'Smartphone', price: 699.99, releaseDate: new Date('2023-08-15'), stock: 150 },
    { name: 'Laptop', price: null, releaseDate: new Date('2024-01-20'), stock: 0 },
    { name: 'Tablet', price: 399.49, releaseDate: undefined, stock: 25 },
    { name: 'Headphones', price: 99.99, releaseDate: new Date('2023-07-30'), stock: 60 },
    { name: '', price: null, releaseDate: null, stock: 10 }  
  ];

}