import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-addition',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, CommonModule],
  templateUrl: './addition.component.html',
  styleUrl: './addition.component.scss'
})
export class AdditionComponent {
  // Properties to hold input values
  num1: number | null = null;
  num2: number | null = null;

  // Method to perform addition
  add() {
    // Check if both inputs have valid values
    if (this.num1 === null || this.num2 === null) {
      alert("Enter valid input in both the input boxes");
      return;
    }
    
    // Check if input values are numeric
    if (isNaN(this.num1) || isNaN(this.num2)) {
      alert("Enter valid numeric values");
      return;
    }
    
    // Perform addition
    const result = this.num1 + this.num2;
    alert(`Addition of ${this.num1} + ${this.num2} = ${result}`);
  }
}
