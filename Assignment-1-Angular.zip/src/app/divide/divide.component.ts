import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-divide',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './divide.component.html',
  styleUrl: './divide.component.scss'
})
export class DivideComponent {
  // Properties to hold input values
  num1: number | null = null;
  num2: number | null = null;

  // Method to perform division
  divide() {
    // Check if both inputs have valid values
    if (this.num1 === null || this.num2 === null) {
      alert("Enter valid input in both input boxes");
      return;
    }

    // Check if second input is zero
    if (this.num2 === 0) {
      alert("Divide by Zero is not possible");
      return;
    }

    // Check if both inputs are numeric
    if (!isNaN(this.num1) && !isNaN(this.num2)) {
      // Perform division
      const result = this.num1 / this.num2;
      alert(`Division of ${this.num1} / ${this.num2} = ${result}`);
    } else {
      alert("Enter valid numeric values");
    }
  }
}
