import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-main-section',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './main-section.component.html',
  styleUrl: './main-section.component.scss'
})
export class MainSectionComponent {
  // Variables to store user input and result
 name: string = ''; // Variable to store name input
}

  