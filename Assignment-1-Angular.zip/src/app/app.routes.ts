import { Routes } from '@angular/router';
import { AdditionComponent } from './addition/addition.component'; // Importing AdditionComponent for addition route
import { SubtractComponent } from './substract/substract.component'; // Importing SubtractComponent for subtraction route
import { multipyComponent } from './multipy/multipy.component'; // Importing multipyComponent for multiplication route
import { DivideComponent } from './divide/divide.component'; // Importing DivideComponent for division route
import { MainSectionComponent } from './main-section/main-section.component'; // Importing MainSectionComponent for default route

// Define the routes array
export const routes: Routes = [
    { path: "", component: MainSectionComponent }, // Default route to MainSectionComponent
    { path: "addition", component: AdditionComponent }, // Route for addition operation
    { path: "substraction", component: SubtractComponent }, // Route for subtraction operation
    { path: "multipy", component: multipyComponent }, // Route for multiplication operation
    { path: "divide", component: DivideComponent }, // Route for division operation
];
