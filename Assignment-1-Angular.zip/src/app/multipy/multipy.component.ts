import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-multipy',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './multipy.component.html',
  styleUrl: './multipy.component.scss'
})
export class multipyComponent {
  // Variables to store input values
  num1: number | null = null;
  num2: number | null = null;

  // Function to perform multiplication
  multipy() {
    // Check if both input values are provided
    if (this.num1 === null || this.num2 === null) {
      alert("Enter valid input in both input boxes");
      return;
    }

    // Check if input values are valid numbers
    if (isNaN(this.num1) || isNaN(this.num2)) {
      alert("Enter valid numeric values");
      return;
    }

    // Perform multiplication
    const result = this.num1 * this.num2;
    // Display the result
    alert(`Multiplication of ${this.num1} * ${this.num2} = ${result}`);
  }
}
