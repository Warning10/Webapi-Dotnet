import { ComponentFixture, TestBed } from '@angular/core/testing';

import { multipyComponent } from './multipy.component';

describe('multipyComponent', () => {
  let component: multipyComponent;
  let fixture: ComponentFixture<multipyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [multipyComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(multipyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
