import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-substract',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './substract.component.html',
  styleUrl: './substract.component.scss'
})
export class SubtractComponent {
  // Initialize variables to store user input
  num1: number | null = null; // First number
  num2: number | null = null; // Second number

  // Method to perform subtraction
  subtract() {
    // Check if both input boxes have valid values
    if (this.num1 === null || this.num2 === null) {
      // Alert user if input is missing
      alert("Enter valid input in both input boxes");
      return; // Exit method
    }

    // Check if input values are numeric
    if (isNaN(this.num1) || isNaN(this.num2)) {
      // Alert user if input values are not numeric
      alert("Enter valid numeric values");
      return; // Exit method
    }

    // Calculate the result of subtraction
    const result = this.num1 - this.num2;

    // Display the result in an alert
    alert(`Subtraction of ${this.num1} - ${this.num2} = ${result}`);
  }
}
