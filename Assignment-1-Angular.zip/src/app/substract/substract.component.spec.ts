import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubtractComponent } from './substract.component';

describe('SubstractComponent', () => {
  let component: SubtractComponent;
  let fixture: ComponentFixture<SubtractComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SubtractComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SubtractComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
