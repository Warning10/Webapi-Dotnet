﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using FluentValidation;
using FluentValidation.Results;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Command
{
    public class UpdateEmployeeCommand : EmployeeCommand
    {
        public int Id { get; set; }
    }

    public class UpdateEmployeeCommandHandler : IRequestHandler<UpdateEmployeeCommand, bool>
    {
        private readonly IGenericRepository<EmployeeModel> _genericRepository;


		public UpdateEmployeeCommandHandler(IGenericRepository<EmployeeModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(UpdateEmployeeCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new EmployeeCommandValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }

            var employee = new EmployeeModel
            {
                Id = request.Id,
                Name = request.Name,
                Email = request.Email,
                Gender = request.Gender,
                Address = request.Address,
                Designation = request.Designation,
                DeptId = request.DeptId,
                DateOfBirth = request.DateOfBirth,
                DateOfJoining = request.DateOfJoining,
                IsActive = request.IsActive,
                Updated = DateTime.UtcNow,
            };

            return await _genericRepository.UpdateAsync(request.Id, employee);
        }
    }
}
