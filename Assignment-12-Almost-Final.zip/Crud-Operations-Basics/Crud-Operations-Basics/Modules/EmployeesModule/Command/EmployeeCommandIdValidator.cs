﻿using FluentValidation;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Command
{
    public class EmployeeCommandIdValidator : AbstractValidator<DeleteEmployeeCommand>
    {

        public EmployeeCommandIdValidator()
        {
            RuleFor(x => x.Id)
            .NotNull()
            .WithMessage("ID cannot be null.")
            .NotEmpty()
            .WithMessage("ID cannot be empty.")
            .GreaterThan(0)
            .WithMessage("ID must be a positive integer.");
        }

    }
}
