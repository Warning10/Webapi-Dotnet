﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Query
{
    public class GetEmployeeByIdQuery : IRequest<EmployeeModel>
    {
        public int Id { get; set; }
    }

    public class GetEmployeeByIdQueryHandler : IRequestHandler< GetEmployeeByIdQuery,EmployeeModel>
    {
        private readonly IGenericRepository<EmployeeModel> _genericRepository;

        public GetEmployeeByIdQueryHandler(IGenericRepository<EmployeeModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<EmployeeModel> Handle(GetEmployeeByIdQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetByIdAsync(request.Id);
        }
    }

}
