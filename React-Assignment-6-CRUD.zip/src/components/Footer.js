import React from "react";
import "../assests/css/Footer.css";

// component for rendering a footer
const Footer = () => {
  // get current date
  const currentDate = new Date();
  const formattedDate = currentDate.toLocaleDateString("en-GB");

  //footer
  return (
    <footer className="main-footer">
      <div className="copyright">
        <p>
          Aress Software & Education Technologies (P) Ltd. © {formattedDate} All
          rights reserved.{" "}
        </p>
      </div>
    </footer>
  );
};

export default Footer;
