import React, { useState } from "react";
import { PostList } from "./PostList";
import { PostForm } from "./PostForm";

export const Post = () => {
  // state to manage content displayed in the component
  const [content, setContent] = useState(<PostList showForm={showForm} />);

  // function to display the post list
  function showList() {
    setContent(<PostList showForm={showForm} />);
  }

  // function to display the post form for editing or creating new posts
  function showForm(posts) {
    setContent(<PostForm posts={posts} showList={showList} />);
  }

  return (
    <div style={{ height: "74vh" }} className="container my-5">
      {content}
    </div>
  );
};
