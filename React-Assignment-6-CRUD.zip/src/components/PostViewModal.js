import React from "react";
import { Modal, Button } from "react-bootstrap";
import "../assests/css/PostViewModal.css";

const PostViewModal = ({ post, onClose }) => {
  return (
    <Modal show={true} onHide={onClose} size="lg">
      <Modal.Header closeButton>
        <Modal.Title>Post Details</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="post-details">
          <p>
            <strong>ID:</strong> {post.id}
          </p>
          <p>
            <strong>Title:</strong>
          </p>
          <p>{post.title}</p>
          <p>
            <strong>Body:</strong>
          </p>
          <div className="body-content">{post.body}</div>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default PostViewModal;
