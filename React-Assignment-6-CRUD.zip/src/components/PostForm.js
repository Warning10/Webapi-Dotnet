import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "../assests/css/PostForm.css";

// validation schema for form fields
const validationSchema = Yup.object().shape({
  title: Yup.string()
    .required("Title is required")
    .matches(
      /^[^\s]+(\s[^\s]+)*$/,
      "Title should not contain special characters and only one blank space between words"
    )
    .min(3, "Title should be at least 3 characters")
    .max(50, "Title should not exceed 50 characters"),
  body: Yup.string()
    .required("Body is required")
    .matches(
      /^[^\s]+(\s[^\s]+)*$/,
      "Body should not contain special characters and only one blank space between words"
    )
    .min(10, "Body should be at least 10 characters")
    .max(500, "Body should not exceed 500 characters"),
});

// functional component for PostForm
export const PostForm = ({ posts, showList }) => {
  const initialValues = {
    title: posts.title || "",
    body: posts.body || "",
  };

  // function to handle form reset
  const handleReset = (resetForm) => {
    resetForm({ values: { title: "", body: "" } });
    toast.info("Form reset successfully");
  };

  // function to handle form submission
  const handleSubmit = (values, { setSubmitting }) => {
    const url = posts.id
      ? `http://localhost:3004/posts/${posts.id}`
      : "http://localhost:3004/posts";

    const method = posts.id ? "patch" : "post";

    // make HTTP request to save or update post
    axios({
      method: method,
      url: url,
      data: values,
    })
      .then((response) => {
        setTimeout(() => {
          toast.success("Post updated successfully");
        }, 500);
        showList();
      })
      .catch((error) => {
        console.error(`Error ${method}ing post:`, error);
      })
      .finally(() => {
        setSubmitting(false);
      });
  };

  return (
    <>
      <ToastContainer />
      <h2 className="text-center mb-3">
        {posts.id ? "Edit Post" : "Create New Post"}
      </h2>
      <div className="row">
        <div className="col-lg-6 mx-auto">
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
            enableReinitialize={true}
          >
            {({ isSubmitting, resetForm }) => (
              <Form>
                <div className="mb-3">
                  <label className="col-form-label">Title</label>
                  <Field type="text" name="title" className="form-control" />
                  <ErrorMessage
                    name="title"
                    component="div"
                    className="alert alert-danger"
                  />
                </div>

                <div className="mb-3">
                  <label className="col-form-label">Body</label>
                  <Field as="textarea" name="body" className="form-control" />
                  <ErrorMessage
                    name="body"
                    component="div"
                    className="alert alert-danger"
                  />
                </div>

                <div className="row">
                  <div className="col-sm-4">
                    <button
                      className="btn btn-primary"
                      type="submit"
                      disabled={isSubmitting}
                    >
                      Save
                    </button>
                  </div>
                  <div className="col-sm-4">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={() => handleReset(resetForm)}
                      disabled={isSubmitting}
                    >
                      Reset
                    </button>
                  </div>
                  <div className="col-sm-4">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={() => showList()}
                      disabled={isSubmitting}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </>
  );
};

export default PostForm;
