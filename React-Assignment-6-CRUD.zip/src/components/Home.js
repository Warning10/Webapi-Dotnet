import React from "react";
import "../assests/css/Home.css";

export const Home = () => {
  return <div className="back-img"></div>;
};
