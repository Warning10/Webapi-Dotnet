import axios from 'axios';

// Define the base URL for your API
const BASE_URL = 'https://localhost:7066/api/Department'; // Update with your .NET Core API URL

export const getDepartmentById = async (id) => {
  try {
    const response = await axios.get(`${BASE_URL}/byid/${id}`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching department with ID ${id}:`, error);
    throw error;
  }
};
