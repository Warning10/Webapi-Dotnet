import React from "react";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import { Home } from "./components/Home";
import { Post } from "./components/Post";
import { BrowserRouter, Route, Routes } from "react-router-dom";

function App() {
  return (
    <div>
      <BrowserRouter>
        <Navbar />
          <Routes>
            <Route path="/" element={<Home />}></Route>
            <Route path="/post" element={<Post />}></Route>
          </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
