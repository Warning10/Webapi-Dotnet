﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Modules.DepartmentsModule.Command;
using Crud_Operations_Basics.Modules.EmployeesModule.Command;
using Crud_Operations_Basics.Repository;
using Crud_Operations_Basics.Utils;
using FluentValidation;
using System.Reflection;

namespace Crud_Operations_Basics.Extensions
{
	public static class ServiceExtensions
    {
        public static void ConfigureCors(this IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy", builder =>
                {
                    builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader();
                });
            });
        }

        public static void AddApplicationLayer(this IServiceCollection services)
        {
            services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));
			services.AddTransient<IValidator<CreateDepartmentCommand>, DepartmentCommand.Validator>();
			services.AddTransient<IValidator<UpdateDepartmentCommand>, DepartmentCommand.Validator>();
			services.AddTransient<IValidator<DeleteDepartmentCommand>, DeleteDepartmentCommand.IdValidator>();
			services.AddTransient<IValidator<CreateEmployeeCommand>, EmployeeCommand.Validators>();
            services.AddTransient<IValidator<UpdateEmployeeCommand>, EmployeeCommand.Validators>();
			services.AddTransient<IValidator<DeleteEmployeeCommand>, DeleteEmployeeCommand.IdValidator>();



			services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));
        }
        public static void CongigureSQLConnection(this IServiceCollection services, IConfiguration configuration) =>
            services.AddSqlServer<ApplicationDbContext>(configuration.GetConnectionString("DatabaseConnection"));
    }
}

