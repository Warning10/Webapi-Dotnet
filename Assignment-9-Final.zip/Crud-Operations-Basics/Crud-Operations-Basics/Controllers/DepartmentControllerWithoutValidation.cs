﻿using Crud_Operations_Basics.Models.Dto;
using Crud_Operations_Basics.Modules.DepartmentsModule.Command;
using Crud_Operations_Basics.Modules.DepartmentsModule.Query;
using Crud_Operations_Basics.Modules.EmployeesModule.Command;
using Crud_Operations_Basics.Utils.Validators;
using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Crud_Operations_Basics.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentControllerWithoutValidation : ControllerBase
    {
        private readonly ISender _mediatR;

        public DepartmentControllerWithoutValidation(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        [HttpGet("all")]
		public async Task<IActionResult> GetAllDepartments()
		{
			var departments = await _mediatR.Send(new GetAllDepartmentsQuery());

			// Check if any departments were found
			if (departments == null || !departments.Any())
			{
				// Return a 404 Not Found if no departments are available
				return NotFound("No departments found.");
			}

			// Return the list of departments
			return Ok(departments);
		}

        [HttpGet("byid/{id}")]
		public async Task<IActionResult> GetDepartmentById([FromRoute] int id)
		{
			var department = await _mediatR.Send(new GetDepartmentByIdQuery { Id = id });

			if (department == null)
			{
				return NotFound(new { Message = $"Department with ID {id} not found." });
			}

			return Ok(department);
		}

        [HttpPost("create")]
        public async Task<object> CreateDepartment([FromBody] CreateDepartmentCommand createDepartmentCommand)
        {

			try
			{
				// Send the command to create the department
				var success = await _mediatR.Send(createDepartmentCommand);

				if (success)
				{
					// Return a Created response with the ID of the newly created department
					// You might want to return the ID or another appropriate response here
					return Ok(new { Message = "Department created successfully." });

				}
				else
				{
					// Return a BadRequest response if creation was unsuccessful
					return BadRequest("Failed to create department.");
				}
			}
			catch (ValidationException ex)
			{
				// Return a BadRequest response with validation errors
				return BadRequest(ex.Errors.Select(e => e.ErrorMessage).ToList());
			}
			catch (Exception ex)
			{
				// Log the exception details (optional)
				// e.g., _logger.LogError(ex, "An error occurred while creating the department.");

				// Return a generic error response
				return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the department.");
			}

		}

        [HttpPut("update/{id}")]
        public async Task<object> UpdateDepartment([FromBody] UpdateDepartmentCommand updateDepartmentCommand, [FromRoute] int id)
        {
			try
			{
				bool isUpdated = await _mediatR.Send(updateDepartmentCommand);
				if (isUpdated)
				{
					// Return a Created response with the ID of the newly created department
					// You might want to return the ID or another appropriate response here
					return Ok(new { Message = "Department updated successfully." });

				}
				else
				{
					// Return a BadRequest response if creation was unsuccessful
					return BadRequest("Failed to create department.");
				}
			}
			catch (ValidationException ex)
			{
				// Return a BadRequest response with validation errors
				return BadRequest(ex.Errors.Select(e => e.ErrorMessage).ToList());
			}
			catch (Exception ex)
			{
				// Log the exception details (optional)
				// e.g., _logger.LogError(ex, "An error occurred while creating the department.");

				// Return a generic error response
				return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the department.");
			}
		}

        [HttpDelete("delete/{id}")]
        public async Task<object> DeleteDepartment([FromRoute]int id)
        {
			try
			{
				var result = await _mediatR.Send(new DeleteDepartmentCommand() { Id = id });
				if (result)
				{
					return Ok();
				}
				else
				{
					return NotFound(new { Message = $"Department with ID {id} not found." });
				}
			}
			catch (ValidationException ex)
			{
				return BadRequest(ex.Errors.Select(e => e.ErrorMessage).ToList());

			}
			catch (Exception ex)
			{
				// Log the exception details (optional)
				// e.g., _logger.LogError(ex, "An error occurred while creating the department.");

				// Return a generic error response
				return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the department.");
			}
		}


    }



}
