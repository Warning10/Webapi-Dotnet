﻿using Crud_Operations_Basics.Models.Dto;
using Crud_Operations_Basics.Modules.DepartmentsModule.Command;
using Crud_Operations_Basics.Modules.DepartmentsModule.Query;
using Crud_Operations_Basics.Modules.EmployeesModule.Command;
using Crud_Operations_Basics.Utils.Validators;
using FluentValidation.Results;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Crud_Operations_Basics.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly ISender _mediatR;

        public DepartmentController(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        [HttpGet("all")]
		public async Task<IActionResult> GetAllDepartments()
		{
			var departments = await _mediatR.Send(new GetAllDepartmentsQuery());

			// Check if any departments were found
			if (departments == null || !departments.Any())
			{
				// Return a 404 Not Found if no departments are available
				return NotFound("No departments found.");
			}

			// Return the list of departments
			return Ok(departments);
		}

        [HttpGet("byid/{id}")]
		public async Task<IActionResult> GetDepartmentById([FromRoute] int id)
		{
			var department = await _mediatR.Send(new GetDepartmentByIdQuery { Id = id });

			if (department == null)
			{
				return NotFound(new { Message = $"Department with ID {id} not found." });
			}

			return Ok(department);
		}

        [HttpPost("create")]
        public async Task<object> CreateDepartment([FromBody] DepartmentDto departmentDto)
        {
			ValidationResult validationResult = new DepartmentValidators().Validate(departmentDto);
			if (!validationResult.IsValid)
			{
				return BadRequest(validationResult.Errors.First().ErrorMessage);
			}
			var createDepartmentCommand = new CreateDepartmentCommand
			{
                DeptName = departmentDto.DeptName
			};
			var isSuccess = await _mediatR.Send(createDepartmentCommand);
			if (!isSuccess)
			{
				return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the Department.");
			}

			return Ok(new { Message = "Department created successfully." }); 

        }

        [HttpPut("update/{id}")]
        public async Task<object> UpdateDepartment([FromBody] DepartmentDto departmentDto, [FromRoute] int id)
        {
			ValidationResult validationResult = new DepartmentValidators().Validate(departmentDto);
			if (!validationResult.IsValid)
			{
				// Return the first validation error message if validation fails
				return BadRequest(validationResult.Errors.First().ErrorMessage);
			}
			var updateDepartmentCommand = new UpdateDepartmentCommand
			{
				Id = id,
				DeptName = departmentDto.DeptName
				
			};
			bool isUpdated = await _mediatR.Send(updateDepartmentCommand);
			if (!isUpdated)
			{
				return NotFound(new { Message = $"Department with ID {id} not found." });
			}

			// If the update was successful, return a success response
			return Ok(new { Message = "Department updated successfully." });
        }

        [HttpDelete("delete/{id}")]
        public async Task<object> DeleteDepartment([FromRoute]int id)
        {
			var validationResult = new IdValidator().Validate(id);
			if (!validationResult.IsValid)
			{
				return BadRequest(validationResult.Errors.ToList()[0].ErrorMessage);
			}
			var result = await _mediatR.Send(new DeleteDepartmentCommand() { Id = id });
			if (result)
			{
				return Ok();
			}

			return NotFound(new { Message = $"Department with ID {id} not found." });
		}


    }



}
