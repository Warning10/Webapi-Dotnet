﻿using Crud_Operations_Basics.Models.Dto;
using Crud_Operations_Basics.Modules.EmployeesModule.Command;
using Crud_Operations_Basics.Modules.EmployeesModule.Query;
using Crud_Operations_Basics.Utils.Validators;
using FluentValidation.Results;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Crud_Operations_Basics.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class EmployeeController : ControllerBase
	{
		private readonly ISender _mediatR;

		public EmployeeController(ISender mediatR)
		{
			_mediatR = mediatR;
		}

		[HttpGet("all")]
		public async Task<IActionResult> GetAllEmployees()
		{
			var result = await _mediatR.Send(new GetAllEmployeesQuery());

			if (result == null)
			{
				return NotFound("No employees found.");
			}

			return Ok(result);
		}


		[HttpGet("byid/{id}")]
		public async Task<IActionResult> GetEmployeeById([FromRoute] int id)
		{
			var result = await _mediatR.Send(new GetEmployeeByIdQuery { Id = id });

			if (result == null)
			{
				return NotFound(new { Message = $"Employee with ID {id} not found." });
			}

			return Ok(result);
		}


		[HttpPost("create")]
		public async Task<object> CreateEmployee([FromBody] EmployeeDto employeeDto)
		{
			ValidationResult validationResult = new EmployeeValidators().Validate(employeeDto);
			if (!validationResult.IsValid)
			{
				// Return the first validation error message if validation fails
				return BadRequest(validationResult.Errors.First().ErrorMessage);
			}

			var createEmployeeCommand = new CreateEmployeeCommand
			{
				FirstName = employeeDto.FirstName,
				LastName = employeeDto.LastName,
				Email = employeeDto.Email,
				Gender = employeeDto.Gender,
				Address = employeeDto.Address,
				Designation = employeeDto.Designation,
				DeptId = employeeDto.DeptId,
				DateOfBirth = employeeDto.DateOfBirth,
				DateOfJoining = employeeDto.DateOfJoining,
				IsActive = employeeDto.IsActive
			};


			var isSuccess = await _mediatR.Send(createEmployeeCommand);
			if (!isSuccess)
			{
				return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the employee.");
			}

			return Ok(new { Message = "Employee created successfully." });

		}

		[HttpPut("update/{id}")]
		public async Task<object> UpdateEmployee([FromBody] EmployeeDto employeeDto, [FromRoute] int id)
		{
			ValidationResult validationResult = new EmployeeValidators().Validate(employeeDto);
			if (!validationResult.IsValid)
			{
				// Return the first validation error message if validation fails
				return BadRequest(validationResult.Errors.First().ErrorMessage);
			}

			var updateEmployeeCommand = new UpdateEmployeeCommand
			{
				Id = id,
				FirstName = employeeDto.FirstName,
				LastName = employeeDto.LastName,
				Email = employeeDto.Email,
				Gender = employeeDto.Gender,
				Address = employeeDto.Address,
				Designation = employeeDto.Designation,
				DeptId = employeeDto.DeptId,
				DateOfBirth = employeeDto.DateOfBirth,
				DateOfJoining = employeeDto.DateOfJoining,
				IsActive = employeeDto.IsActive,
			};
			bool isUpdated = await _mediatR.Send(updateEmployeeCommand);
			if (!isUpdated)
			{
				return NotFound(new { Message = $"Employee with ID {id} not found." });
			}

			// If the update was successful, return a success response
			return Ok(new { Message = "Employee updated successfully." });
		}

		[HttpDelete("delete/{id}")]
		public async Task<object> DeleteEmployee([FromRoute] int id)
		{
			var validationResult = new IdValidator().Validate(id);
			if (!validationResult.IsValid)
			{
				return BadRequest(validationResult.Errors.ToList()[0].ErrorMessage);
			}

			var result = await _mediatR.Send(new DeleteEmployeeCommand() { Id = id });
			if (result)
			{
				return Ok();
			}

			return NotFound(new { Message = $"Employee with ID {id} not found." });
		}


	}



}
