﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using Crud_Operations_Basics.Modules.DepartmentsModule.Command;
using FluentValidation;
using FluentValidation.Results;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Command
{
    public class UpdateEmployeeCommand : EmployeeCommand
    {
        public int Id { get; set; }
    }

    public class UpdateEmployeeCommandHandler : IRequestHandler<UpdateEmployeeCommand, bool>
    {
        private readonly IGenericRepository<Models.EmployeeModel> _genericRepository;
		private readonly IValidator<UpdateEmployeeCommand> _validator;


		public UpdateEmployeeCommandHandler(IGenericRepository<Models.EmployeeModel> genericRepository, IValidator<UpdateEmployeeCommand> validator)
        {
            _genericRepository = genericRepository;
            _validator = validator;
        }

        public async Task<bool> Handle(UpdateEmployeeCommand request, CancellationToken cancellationToken)
        {
			ValidationResult validationResult = await _validator.ValidateAsync(request, cancellationToken);
			if (!validationResult.IsValid)
			{
				// Handle validation failures (could throw an exception or return an error)
				throw new ValidationException(validationResult.Errors);
			}
			var existingEmployee = await _genericRepository.GetByIdAsync(request.Id);
            if (existingEmployee == null)
            {
                return false;
            }

            existingEmployee.FirstName = request.FirstName;
            existingEmployee.LastName = request.LastName;
            existingEmployee.Email = request.Email;
            existingEmployee.Gender = request.Gender;
            existingEmployee.Address = request.Address;
            existingEmployee.Designation = request.Designation;
            existingEmployee.DeptId = request.DeptId;
            existingEmployee.DateOfBirth = request.DateOfBirth;
            existingEmployee.DateOfJoining = request.DateOfJoining;
            existingEmployee.IsActive = request.IsActive;
            existingEmployee.Updated = DateTime.UtcNow;

            return await _genericRepository.UpdateAsync(request.Id, existingEmployee);

        }
    }
}
