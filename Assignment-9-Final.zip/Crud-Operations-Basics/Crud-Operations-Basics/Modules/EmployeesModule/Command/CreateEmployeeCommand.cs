﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using Crud_Operations_Basics.Modules.DepartmentsModule.Command;
using FluentValidation;
using FluentValidation.Results;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Command
{
    public class CreateEmployeeCommand : EmployeeCommand { }

    public class CreateEmployeeCommandHandler : IRequestHandler<CreateEmployeeCommand, bool>
    {
        private readonly IGenericRepository<Models.EmployeeModel> _genericRepository;
		private readonly IValidator<CreateEmployeeCommand> _validator;

		public CreateEmployeeCommandHandler(IGenericRepository<Models.EmployeeModel> genericRepository, IValidator<CreateEmployeeCommand> validator)
        {
            _genericRepository = genericRepository;
            _validator = validator;
        }

        public async Task<bool> Handle(CreateEmployeeCommand request, CancellationToken cancellationToken)
        {
			ValidationResult validationResult = await _validator.ValidateAsync(request, cancellationToken);
			if (!validationResult.IsValid)
			{
				// Handle validation failures (could throw an exception or return an error)
				throw new ValidationException(validationResult.Errors);
			}
			var employeeModel = new EmployeeModel
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Gender = request.Gender,
                Address = request.Address,
                Designation = request.Designation,
                DeptId = request.DeptId,
                DateOfBirth = request.DateOfBirth,
                DateOfJoining = request.DateOfJoining,
                IsActive = request.IsActive,
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            };
            return await _genericRepository.AddAsync(employeeModel);
        }
    }
}
