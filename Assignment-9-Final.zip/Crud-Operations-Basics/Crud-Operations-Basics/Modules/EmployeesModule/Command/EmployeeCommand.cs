﻿using Crud_Operations_Basics.Models.Dto;
using FluentValidation;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Command
{
    public class EmployeeCommand : IRequest<bool>
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string Gender { get; set; }

        public string Address { get; set; }

        public string Designation { get; set; }

        public int DeptId { get; set; }

        public DateTime DateOfBirth { get; set; }

        public DateTime DateOfJoining { get; set; }

        public bool IsActive { get; set; }

		public class Validators : AbstractValidator<EmployeeCommand>
		{
			public Validators()
			{

				RuleFor(x => x.FirstName)
				.NotNull()
				.WithMessage("First name cannot be null.")
				.NotEmpty()
				.WithMessage("First name cannot be empty.")
				.Length(1, 50)
				.WithMessage("First name must be between 1 and 50 characters.");

				RuleFor(x => x.LastName)
					.NotNull()
					.WithMessage("Last name cannot be null.")
					.NotEmpty()
					.WithMessage("Last name cannot be empty.")
					.Length(1, 50)
					.WithMessage("Last name must be between 1 and 50 characters.");

				RuleFor(x => x.Email)
					.NotNull()
					.WithMessage("Email cannot be null.")
					.NotEmpty()
					.WithMessage("Email is required.")
					.EmailAddress()
					.WithMessage("Invalid email address format.")
					.Length(1, 100)
					.WithMessage("Email must not exceed 100 characters.");

				RuleFor(x => x.Gender)
					.NotNull()
					.WithMessage("Gender cannot be null.")
					.NotEmpty()
					.WithMessage("Gender is required.")
					.Length(1)
					.WithMessage("Gender must be a single character.");

				RuleFor(x => x.Address)
					.NotNull()
					.WithMessage("Address cannot be null.")
					.NotEmpty()
					.WithMessage("Address is required.")
					.Length(1, 255)
					.WithMessage("Address must be between 1 and 255 characters.");

				RuleFor(x => x.Designation)
					.NotNull()
					.WithMessage("Designation cannot be null.")
					.NotEmpty()
					.WithMessage("Designation is required.")
					.Length(1, 100)
					.WithMessage("Designation must be between 1 and 100 characters.");

				RuleFor(x => x.DeptId)
					.GreaterThan(0)
					.WithMessage("Department ID must be greater than zero.");

				RuleFor(x => x.DateOfBirth)
					.NotNull()
					.WithMessage("Date of birth cannot be null.")
					.NotEmpty()
					.WithMessage("Date of birth is required.")
					.Must(date => date < DateTime.UtcNow)
					.WithMessage("Date of birth must be in the past.");

				RuleFor(x => x.DateOfJoining)
					.NotNull()
					.WithMessage("Date of joining cannot be null.")
					.NotEmpty()
					.WithMessage("Date of joining is required.")
					.Must(date => date <= DateTime.UtcNow)
					.WithMessage("Date of joining must be in the past or today.");

				RuleFor(x => x.IsActive)
					.NotNull()
					.WithMessage("Active status is required.");

			}
		}
	}

	
}
