﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Modules.DepartmentsModule.Command;
using Crud_Operations_Basics.Utils.Validators;
using FluentValidation;
using FluentValidation.Results;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Command
{
    public class DeleteEmployeeCommand : EmployeeCommand
    {
        public int Id { get; set; }

		public class IdValidator : AbstractValidator<DeleteEmployeeCommand>
		{
			public IdValidator()
			{
				RuleFor(x => x.Id)
				.NotNull()
				.WithMessage("ID cannot be null.")
				.NotEmpty()
				.WithMessage("ID cannot be empty.")
				.GreaterThan(0)
				.WithMessage("ID must be a positive integer.");
			}
		}

	}
    public class DeleteEmployeeCommandHandler : IRequestHandler<DeleteEmployeeCommand, bool>
    {
        private readonly IGenericRepository<Models.EmployeeModel> _genericRepository;
		private readonly IValidator<DeleteEmployeeCommand> _validator;

		public DeleteEmployeeCommandHandler(IGenericRepository<Models.EmployeeModel> genericRepository, IValidator<DeleteEmployeeCommand> validator)
        {
            _genericRepository = genericRepository;
			_validator = validator;
        }

        public async Task<bool> Handle(DeleteEmployeeCommand request, CancellationToken cancellationToken)
        {
			ValidationResult validationResult = await _validator.ValidateAsync(request, cancellationToken);
			if (!validationResult.IsValid)
			{
				// Handle validation failures (could throw an exception or return an error)
				throw new ValidationException(validationResult.Errors);
			}
			var existingEmployee = await _genericRepository.GetByIdAsync(request.Id);
            if (existingEmployee == null)
            {
                return false;
            }
            return await _genericRepository.DeleteAsync(request.Id);

        }

    }

}
