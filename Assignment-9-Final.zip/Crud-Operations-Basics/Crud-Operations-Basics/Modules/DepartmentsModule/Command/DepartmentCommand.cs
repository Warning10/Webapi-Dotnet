﻿using FluentValidation;
using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Command
{
    public class DepartmentCommand : IRequest<bool>
    {
        public string DeptName { get; set; }

		public class Validator : AbstractValidator<DepartmentCommand>
		{
			public Validator()
			{
				RuleFor(x => x.DeptName)
					.NotNull()
					.WithMessage("Department name cannot be null.")
					.NotEmpty()
					.WithMessage("Department name is required.")
					.Length(1, 100)
					.WithMessage("Department name must be between 1 and 100 characters.");
			}
		}
	}
}
