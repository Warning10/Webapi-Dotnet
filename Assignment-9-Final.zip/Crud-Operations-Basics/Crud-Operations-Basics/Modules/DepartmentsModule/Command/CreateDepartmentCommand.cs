﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using Crud_Operations_Basics.Models.Dto;
using FluentValidation;
using FluentValidation.Results;
using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Command
{
    public class CreateDepartmentCommand : DepartmentCommand { }

    public class CreateDepartmentCommandHandler : IRequestHandler<CreateDepartmentCommand, bool>
    {
        private readonly IGenericRepository<Models.DepartmentModel> _genericRepository;
		private readonly IValidator<CreateDepartmentCommand> _validator;


		public CreateDepartmentCommandHandler(IGenericRepository<Models.DepartmentModel> genericRepository, IValidator<CreateDepartmentCommand> validator)
        {
            _genericRepository = genericRepository;
            _validator = validator;
        }

        public async Task<bool> Handle(CreateDepartmentCommand request, CancellationToken cancellationToken)
        {
			ValidationResult validationResult = await _validator.ValidateAsync(request, cancellationToken);
			if (!validationResult.IsValid)
			{
				// Handle validation failures (could throw an exception or return an error)
				throw new ValidationException(validationResult.Errors);
			}
			var departmentModel = new DepartmentModel
            {
                DeptName = request.DeptName,
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow,
            };
            return await _genericRepository.AddAsync(departmentModel);
        }
    }
}
