﻿namespace Crud_Operations_Basics.Models.Dto
{
	public class DepartmentDto
	{
        public string DeptName { get; set; }  
    }
}
