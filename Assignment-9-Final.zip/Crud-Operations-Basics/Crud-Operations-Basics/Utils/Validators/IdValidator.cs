﻿using Crud_Operations_Basics.Models;
using FluentValidation;

namespace Crud_Operations_Basics.Utils.Validators
{
    public class IdValidator : AbstractValidator<int>
    {
        public IdValidator()
        {
            RuleFor(id => id)
            .NotNull()
            .WithMessage("ID cannot be null.")
            .NotEmpty()
            .WithMessage("ID cannot be empty.")
            .GreaterThan(0)
            .WithMessage("ID must be a positive integer.");
        }
    }
}
