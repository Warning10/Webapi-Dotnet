﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Utils;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.EntityFrameworkCore;

namespace Crud_Operations_Basics.Repository
{
	public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private readonly ApplicationDbContext _context;
        private readonly DbSet<T> _dbSet;

        public GenericRepository(ApplicationDbContext context)
        {
            _context = context;
            _dbSet = _context.Set<T>();
        }
        public async  Task<List<T>> GetAllAsync()
        {
            return await _dbSet.ToListAsync();
        }
        public async Task<T> GetByIdAsync(int id)
        {
            return await _dbSet.FindAsync(id);
        }

        public async Task<bool> AddAsync(T entity)
        {
			try
			{
				_dbSet.Add(entity);
				await _context.SaveChangesAsync();
				return true;
			}
			catch (Exception)
			{
				return false;
			}
		}

        public async Task<bool> UpdateAsync(int Id, T entity)
        {
            var result = await _dbSet.FindAsync(Id);
            if (result != null)
            {
                _context.Entry(result).CurrentValues.SetValues(entity);
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }

		public async Task UpdatePatchAsync(int id, JsonPatchDocument patchDoc)
		{
			var entity = await _dbSet.FindAsync(id);
			if (entity != null)
			{
				// Apply the patch document to the entity
				patchDoc.ApplyTo(entity);
				await _context.SaveChangesAsync();
			}
		}
		public async Task<bool> DeleteAsync(int Id)
        {
            var entity = await _dbSet.FindAsync(Id);
            if (entity != null)
            {
                _dbSet.Remove(entity);
                await _context.SaveChangesAsync();
                return true;
            }

            return false;
        }
    }
}
