﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using FluentValidation;
using FluentValidation.Results;
using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Command
{
    public class UpdateDepartmentCommand : DepartmentCommand
    {
        public int Id { get; set; }
    }

    public class UpdateDepartmentCommandHandler : IRequestHandler<UpdateDepartmentCommand, bool>
    {
        private readonly IGenericRepository<Models.DepartmentModel> _genericRepository;
		private readonly IValidator<UpdateDepartmentCommand> _validator;


		public UpdateDepartmentCommandHandler(IGenericRepository<Models.DepartmentModel> genericRepository, IValidator<UpdateDepartmentCommand> validator)
        {
            _genericRepository = genericRepository;
            _validator = validator;
        }

        public async Task<bool> Handle(UpdateDepartmentCommand request, CancellationToken cancellationToken)
        {
			ValidationResult validationResult = await _validator.ValidateAsync(request, cancellationToken);
			if (!validationResult.IsValid)
			{
				// Handle validation failures (could throw an exception or return an error)
				throw new ValidationException(validationResult.Errors);
			}

			var existingDepartment = await _genericRepository.GetByIdAsync(request.Id);
            if (existingDepartment == null)
            {
                return false;
            }

            existingDepartment.DeptName = request.DeptName;
            existingDepartment.Updated = DateTime.UtcNow;
            return await _genericRepository.UpdateAsync(request.Id, existingDepartment);

        }
    }
}
