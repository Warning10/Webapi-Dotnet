﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Modules.EmployeesModule.Command;
using Crud_Operations_Basics.Repository;
using FluentValidation;
using FluentValidation.Results;
using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Command
{
	public class DeleteDepartmentCommand : DepartmentCommand
	{
		public int Id { get; set; }

		public class IdValidator : AbstractValidator<DeleteDepartmentCommand>
		{
			public IdValidator()
			{
				RuleFor(x => x.Id)
				.NotNull()
				.WithMessage("ID cannot be null.")
				.NotEmpty()
				.WithMessage("ID cannot be empty.")
				.GreaterThan(0)
				.WithMessage("ID must be a positive integer.");
			}
		}
	}
	public class DeleteDepartmentCommandHandler : IRequestHandler<DeleteDepartmentCommand, bool>
	{
		private readonly IGenericRepository<Models.DepartmentModel> _genericRepository;
		private readonly IValidator<DeleteDepartmentCommand> _validator;

		public DeleteDepartmentCommandHandler(IGenericRepository<Models.DepartmentModel> genericRepository, IValidator<DeleteDepartmentCommand> validator)
		{
			_genericRepository = genericRepository;
			_validator = validator;
		}

		public async Task<bool> Handle(DeleteDepartmentCommand request, CancellationToken cancellationToken)
		{
			ValidationResult validationResult = await _validator.ValidateAsync(request, cancellationToken);
			if (!validationResult.IsValid)
			{
				// Handle validation failures (could throw an exception or return an error)
				throw new ValidationException(validationResult.Errors);
			}
			var existingDepartment = await _genericRepository.GetByIdAsync(request.Id);
			if (existingDepartment == null)
			{
				return false;
			}
			return await _genericRepository.DeleteAsync(request.Id);

		}

	}

}
