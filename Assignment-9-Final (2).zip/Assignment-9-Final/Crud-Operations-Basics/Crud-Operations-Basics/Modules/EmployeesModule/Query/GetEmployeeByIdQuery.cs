﻿using Crud_Operations_Basics.Interfaces;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Query
{
    public class GetEmployeeByIdQuery : IRequest<Models.EmployeeModel>
    {
        public int Id { get; set; }
    }

    public class GetEmployeeByIdQueryHandler : IRequestHandler< GetEmployeeByIdQuery, Models.EmployeeModel>
    {
        private readonly IGenericRepository<Models.EmployeeModel> _genericRepository;

        public GetEmployeeByIdQueryHandler(IGenericRepository<Models.EmployeeModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<Models.EmployeeModel> Handle(GetEmployeeByIdQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetByIdAsync(request.Id);
        }
    }

}
