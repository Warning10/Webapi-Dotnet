﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Crud_Operations_Basics.Models
{
    public class EmployeeModel
    {
        [Key]
        public int Id { get; set; }

        //[Required(ErrorMessage = "First name is required.")]
        //[StringLength(50, MinimumLength = 1, ErrorMessage = "First name must be between 1 and 50 characters.")]
        public string FirstName { get; set; }

        //[Required(ErrorMessage = "Last name is required.")]
        //[StringLength(50, MinimumLength = 1, ErrorMessage = "Last name must be between 1 and 50 characters.")]
        public string LastName { get; set; }

        //Required(ErrorMessage = "Email is required.")]
        //EmailAddress(ErrorMessage = "Invalid email address format.")]
        //[StringLength(100, ErrorMessage = "Email must not exceed 100 characters.")]
        public string Email { get; set; }

        //[Required(ErrorMessage = "Gender is required.")]
        //[StringLength(1, MinimumLength = 1, ErrorMessage = "Gender must be a single character.")]
        public string Gender { get; set; }

        //[Required(ErrorMessage = "Address is required.")]
        //[StringLength(255, MinimumLength = 1, ErrorMessage = "Address must be between 1 and 255 characters.")]
        public string Address { get; set; }

        //[Required(ErrorMessage = "Designation is required.")]
        //[StringLength(100, MinimumLength = 1, ErrorMessage = "Designation must be between 1 and 100 characters.")]
        public string Designation { get; set; }

        //[Required(ErrorMessage = "Department ID is required.")]
        public int DeptId { get; set; } // Foreign key property
        public DepartmentModel Department { get; set; }

        //[Required(ErrorMessage = "Date of birth is required.")]
        //[DataType(DataType.Date, ErrorMessage = "Invalid date format for date of birth.")]
        public DateTime DateOfBirth { get; set; }

        //[Required(ErrorMessage = "Date of joining is required.")]
        //[DataType(DataType.Date, ErrorMessage = "Invalid date format for date of joining.")]
        public DateTime DateOfJoining { get; set; }

        //[Required(ErrorMessage = "Active status is required.")]
        public bool IsActive { get; set; }

        public DateTime Created { get; set; } = DateTime.UtcNow;

        public DateTime Updated { get; set; } = DateTime.UtcNow;


    }
}
