﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using Crud_Operations_Basics.Models.Dto;
using Crud_Operations_Basics.Repository;
using Crud_Operations_Basics.Utils.Validators;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;

namespace Crud_Operations_Basics.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly IDepartmentRepository _departmentRepository;


        public DepartmentController(IDepartmentRepository departmentRepository)
        {
            _departmentRepository = departmentRepository;

        }
        [HttpGet("getall")]
        public async Task<IActionResult> GetAllDepartments()
        {

            var departments = await _departmentRepository.GetAllDepartmentsAsync();
            if (departments == null)
            {
                return NotFound();
            }
            return Ok(departments);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetDepartmentsById([FromRoute] int id)
        {

            var department = await _departmentRepository.GetDepartmentsByIdAsync(id);
            if (department == null)
            {
                return NotFound();
            }
            return Ok(department);
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddNewDepartment([FromBody] DepartmentDto departmentDto)
        {
            ValidationResult validationResult = new DepartmentValidators().Validate(departmentDto);
            if (validationResult.IsValid)
            {

                var id = await _departmentRepository.AddDepartmentsAsync(departmentDto);
                return CreatedAtAction(nameof(GetDepartmentsById), new { id, controller = "Department" }, id);
            }
            return BadRequest(validationResult.Errors.ToList()[0].ErrorMessage);
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateDepartments([FromBody] DepartmentDto departmentDto, [FromRoute] int id)
        {
            ValidationResult validationResult = new DepartmentValidators().Validate(departmentDto);
            if (validationResult.IsValid)
            {

                await _departmentRepository.UpdateDepartmentsAsync(id, departmentDto);
                return Ok();
            }
            return BadRequest(validationResult.Errors.ToList()[0].ErrorMessage);

        }

        [HttpPatch("patch/update/{id}")]
        public async Task<IActionResult> UpdateDepartmentPatch([FromBody] JsonPatchDocument<DepartmentDto> patchDocument, [FromRoute] int id)
        {
			if (patchDocument == null) return BadRequest("Invalid patch document.");

			var department = await _departmentRepository.GetDepartmentsByIdAsync(id);
			if (department == null) return NotFound();

			var departmentDto = new DepartmentDto
			{
				DeptName = department.DeptName,
			};

			patchDocument.ApplyTo(departmentDto, ModelState);

			if (!ModelState.IsValid) return BadRequest(ModelState);

			var validationResult = new DepartmentValidators().Validate(departmentDto);
			if (!validationResult.IsValid) return BadRequest(validationResult.Errors.ToList()[0].ErrorMessage);

			await _departmentRepository.UpdateDepartmentsPatchAsync(id, patchDocument);

			return NoContent();

		}

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteEmployee([FromRoute] int id)
        {
            var validationResult = new IdValidator().Validate(id);
            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors.ToList()[0].ErrorMessage);
            }
            var result = await _departmentRepository.DeleteDepartmentsAsync(id);
            if (result)
            {
                return Ok();
            }

            return NotFound();
        }
    }
}
