﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models.Dto;
using Crud_Operations_Basics.Utils.Validators;
using FluentValidation.Results;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;

namespace Crud_Operations_Basics.Controllers
{
	[Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeRepository _employeeRepository;

        public EmployeeController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        [HttpGet("getall")]
        public async Task<IActionResult> GetAllEmployees()
        {

            var employees = await _employeeRepository.GetAllEmployeesAsync();
            if (employees == null)
            {
                return NotFound();
            }
            return Ok(employees);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetEmployeesById([FromRoute] int id)
        {

            var employee = await _employeeRepository.GetEmployeesByIdAsync(id);
            if (employee == null)
            {
                return NotFound();
            }
            return Ok(employee);
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddNewEmployee([FromBody] EmployeeDto createEmployeeDto)
        {
            ValidationResult validationResult = new EmployeeValidators().Validate(createEmployeeDto);
            if (validationResult.IsValid)
            {
                var id = await _employeeRepository.AddEmployeesAsync(createEmployeeDto);
                return CreatedAtAction(nameof(GetEmployeesById), new { id, controller = "Employee" }, id);
            }
            return BadRequest(validationResult.Errors.ToList()[0].ErrorMessage);
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateEmployee([FromBody] EmployeeDto updatedEmployeeDto, [FromRoute] int id)
        {
            ValidationResult validationResult = new EmployeeValidators().Validate(updatedEmployeeDto);
            if (validationResult.IsValid)
            {
                await _employeeRepository.UpdateEmployeesAsync(id, updatedEmployeeDto);
                return Ok();
            }
            return BadRequest(validationResult.Errors.ToList()[0].ErrorMessage);
        }

        [HttpPatch("patch/update/{id}")]
        public async Task<IActionResult> UpdateEmployeePatch([FromBody] JsonPatchDocument<EmployeeDto> patchDocument, [FromRoute] int id)
        {
			if (patchDocument == null) return BadRequest("Invalid patch document.");

			var employee = await _employeeRepository.GetEmployeesByIdAsync(id);
			if (employee == null) return NotFound();

			var employeeDto = new EmployeeDto
			{
				FirstName = employee.FirstName,
				LastName = employee.LastName,
				Email = employee.Email,
				Gender = employee.Gender,
				Address = employee.Address,
				Designation = employee.Designation,
				DeptId = employee.DeptId,
				DateOfBirth = employee.DateOfBirth,
				DateOfJoining = employee.DateOfJoining,
				IsActive = employee.IsActive
			};

			patchDocument.ApplyTo(employeeDto, ModelState);

			if (!ModelState.IsValid) return BadRequest(ModelState);

			var validationResult = new EmployeeValidators().Validate(employeeDto);
			if (!validationResult.IsValid) return BadRequest(validationResult.Errors.ToList()[0].ErrorMessage);

			await _employeeRepository.UpdateEmployeesPatchAsync(id, patchDocument);

			return NoContent();

		}

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteEmployee([FromRoute] int id)
        {
            var validationResult = new IdValidator().Validate(id);
            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors.ToList()[0].ErrorMessage);
            }

            var result = await _employeeRepository.DeleteEmployeesAsync(id);
            if (result)
            {
                return Ok();
            }

            return NotFound();
        }
    }
}
