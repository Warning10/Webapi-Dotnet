﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Command
{
    public class UpdateDepartmentCommand : DepartmentCommand
    {
        public int Id { get; set; }
    }

    public class UpdateDepartmentCommandHandler : IRequestHandler<UpdateDepartmentCommand, bool>
    {
        private readonly IGenericRepository<Models.DepartmentModel> _genericRepository;

        public UpdateDepartmentCommandHandler(IGenericRepository<Models.DepartmentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(UpdateDepartmentCommand request, CancellationToken cancellationToken)
        {
            var existingDepartment = await _genericRepository.GetByIdAsync(request.Id);
            if (existingDepartment == null)
            {
                return false;
            }

            existingDepartment.DeptName = request.DeptName;
            existingDepartment.Updated = DateTime.UtcNow;
            return await _genericRepository.UpdateAsync(request.Id, existingDepartment);

        }
    }
}
