﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using Crud_Operations_Basics.Models.Dto;
using Crud_Operations_Basics.Utils;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Crud_Operations_Basics.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly ApplicationDbContext _context;

        public EmployeeRepository(ApplicationDbContext context)
        {
            _context = context;
        }
         public async Task<List<EmployeeModel>> GetAllEmployeesAsync()
        {
            return await _context.Employees.ToListAsync();
        }

        public async Task<EmployeeModel> GetEmployeesByIdAsync(int employeeId)
        {
            return await _context.Employees.Where(x => x.Id == employeeId).FirstOrDefaultAsync();
        }

        public async Task<int> AddEmployeesAsync(EmployeeDto createEmployeeDto)
        {
			var employeeModel = new EmployeeModel
			{
				FirstName = createEmployeeDto.FirstName,
				LastName = createEmployeeDto.LastName,
				Email = createEmployeeDto.Email,
				Gender = createEmployeeDto.Gender,
				Address = createEmployeeDto.Address,
				Designation = createEmployeeDto.Designation,
				DeptId = createEmployeeDto.DeptId,
				DateOfBirth = createEmployeeDto.DateOfBirth,
				DateOfJoining = createEmployeeDto.DateOfJoining,
				IsActive = createEmployeeDto.IsActive,
				Created = DateTime.UtcNow,
				Updated = DateTime.UtcNow
			};
			_context.Employees.Add(employeeModel);
            await _context.SaveChangesAsync();
            return employeeModel.Id;
        }

        public async Task UpdateEmployeesAsync(int employeeId, EmployeeDto updateEmployeeDto)
        {
            var employee = await _context.Employees.FindAsync(employeeId);
            if (employee != null)
            {
				employee.FirstName = updateEmployeeDto.FirstName;
				employee.LastName = updateEmployeeDto.LastName;
				employee.Email = updateEmployeeDto.Email;
				employee.Gender = updateEmployeeDto.Gender;
				employee.Address = updateEmployeeDto.Address;
				employee.Designation = updateEmployeeDto.Designation;
				employee.DeptId = updateEmployeeDto.DeptId;
				employee.DateOfBirth = updateEmployeeDto.DateOfBirth;
				employee.DateOfJoining = updateEmployeeDto.DateOfJoining;
				employee.IsActive = updateEmployeeDto.IsActive;
				employee.Updated = DateTime.UtcNow;

				await _context.SaveChangesAsync();
            }
        }
        public async Task UpdateEmployeesPatchAsync(int employeeId, JsonPatchDocument<EmployeeDto> patchDocument)
        {
			var employee = await GetEmployeesByIdAsync(employeeId);
			if (employee == null) throw new KeyNotFoundException("Employee not found");

			var employeeDto = new EmployeeDto
			{
				FirstName = employee.FirstName,
				LastName = employee.LastName,
				Email = employee.Email,
				Gender = employee.Gender,
				Address = employee.Address,
				Designation = employee.Designation,
				DeptId = employee.DeptId,
				DateOfBirth = employee.DateOfBirth,
				DateOfJoining = employee.DateOfJoining,
				IsActive = employee.IsActive,
			};

			patchDocument.ApplyTo(employeeDto);

			// Map updated DTO back to the entity
			employee.FirstName = employeeDto.FirstName;
			employee.LastName = employeeDto.LastName;
			employee.Email = employeeDto.Email;	
			employee.Gender = employeeDto.Gender;
			employee.Address = employeeDto.Address;
			employee.Designation = employeeDto.Designation;
			employee.DeptId = employeeDto.DeptId;
			employee.DateOfBirth = employeeDto.DateOfBirth;
			employee.DateOfJoining = employeeDto.DateOfJoining;
			employee.IsActive = employeeDto.IsActive;
			employee.Updated = DateTime.UtcNow;

			await _context.SaveChangesAsync();
		}
        

        public async Task<bool> DeleteEmployeesAsync(int employeeId)
        {
            var employee = await _context.Employees.Where(x => x.Id == employeeId).FirstOrDefaultAsync();
            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
