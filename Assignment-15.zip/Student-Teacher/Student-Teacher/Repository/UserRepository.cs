﻿using Student_Teacher.Interfaces;
using Student_Teacher.Models;

namespace Student_Teacher.Repository
{
	public class UserRepository : IUserRepository
	{
		private static List<User> _users = new List<User>
	{
		new User { Id = 1, Username = "testuser", PasswordHash = "hashedpassword", RefreshToken = null, RefreshTokenExpiryTime = DateTime.UtcNow }
	};

		public User GetUserByUsername(string username)
		{
			return _users.SingleOrDefault(u => u.Username == username);
		}

		public void UpdateUser(User user)
		{
			var existingUser = _users.SingleOrDefault(u => u.Id == user.Id);
			if (existingUser != null)
			{
				existingUser.RefreshToken = user.RefreshToken;
				existingUser.RefreshTokenExpiryTime = user.RefreshTokenExpiryTime;
			}
		}
	}
}
