﻿using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.TeacherModule.Command
{
    public class UpdateTeacherCommand : TeacherCommand
    {
        public Guid Id { get; set; }
    }

    public class UpdateTeacherCommandHandler : IRequestHandler<UpdateTeacherCommand, bool>
    {
        private readonly IGenericRepository<TeacherModel> _genericRepository;


        public UpdateTeacherCommandHandler(IGenericRepository<TeacherModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(UpdateTeacherCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new TeacherCommandValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }

            var result = await _genericRepository.GetByIdAsync(request.Id);
            if (result == null)
            {
                return false;
            }

            result.Id = request.Id;
            result.FirstName = request.FirstName;
            result.LastName = request.LastName;
            result.Email = request.Email;
            result.Gender = request.Gender;
            result.DeptId = request.DeptId;
            result.HireDate = request.HireDate;
            result.Position = request.Position;
            result.Updated = DateTime.Now;

            _genericRepository.SaveData();

            return true;
        }
    }
}

