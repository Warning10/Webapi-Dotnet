﻿using MediatR;

namespace Student_Teacher.Modules.DepartmentModule.Command
{
    public class DepartmentCommand : IRequest<bool>
    {
        public string DeptName { get; set; }
    }
}
