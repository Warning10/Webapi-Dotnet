﻿using MediatR;
using Student_Teacher;
using Student_Teacher.Models;
using Student_Teacher.Modules.DepartmentModule.Command;

namespace Department_Teacher.Modules.DepartmentModule.Command
{
    public class DeleteDepartmentCommand : DepartmentCommand
    {
        public Guid Id { get; set; }
    }
    public class DeleteDepartmentCommandHandler : IRequestHandler<DeleteDepartmentCommand, bool>
    {
        private readonly IGenericRepository<DepartmentModel> _genericRepository;

        public DeleteDepartmentCommandHandler(IGenericRepository<DepartmentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(DeleteDepartmentCommand request, CancellationToken cancellationToken)
        {
            var result = await _genericRepository.GetByIdAsync(request.Id);
            if (result == null)
            {
                return false;
            }
            return await _genericRepository.DeleteAsync(request.Id);
        }

    }

}
