﻿using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Student_Teacher;
using Student_Teacher.Models;
using Student_Teacher.Modules.DepartmentModule.Command;

namespace Department_Teacher.Modules.DepartmentModule.Command
{
    public class UpdateDepartmentCommand : DepartmentCommand
    {
        public Guid Id { get; set; }
    }

    public class UpdateDepartmentCommandHandler : IRequestHandler<UpdateDepartmentCommand, bool>
    {
        private readonly IGenericRepository<DepartmentModel> _genericRepository;


        public UpdateDepartmentCommandHandler(IGenericRepository<DepartmentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(UpdateDepartmentCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new DepartmentCommandValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }

            var result = await _genericRepository.GetByIdAsync(request.Id);
            if (result == null)
            {
                return false;
            }

            result.DeptId = request.Id;
            result.DeptName = request.DeptName;
            result.Updated = DateTime.Now;

            _genericRepository.SaveData();

            return true;
        }
    }
}


