﻿using MediatR;
using Student_Teacher;
using Student_Teacher.Models;

namespace Department_Teacher.Modules.DepartmentModule.Query
{
    public class GetDepartmentQuery : IRequest<List<DepartmentModel>> { }

    public class GetDepartmentQuerytHandler : IRequestHandler<GetDepartmentQuery, List<DepartmentModel>>
    {
        private readonly IGenericRepository<DepartmentModel> _genericRepository;

        public GetDepartmentQuerytHandler(IGenericRepository<DepartmentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }
        public async Task<List<DepartmentModel>> Handle(GetDepartmentQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetAllAsync();
        }
    }
}

