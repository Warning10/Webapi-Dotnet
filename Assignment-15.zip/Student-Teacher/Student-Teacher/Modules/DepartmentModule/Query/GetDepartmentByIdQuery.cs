﻿using MediatR;
using Student_Teacher;
using Student_Teacher.Models;

namespace Department_Teacher.Modules.DepartmentModule.Query
{
    public class GetDepartmentByIdQuery : IRequest<DepartmentModel>
    {
        public Guid Id { get; set; }
    }

    public class GetDepartmentByIdQueryHandler : IRequestHandler<GetDepartmentByIdQuery, DepartmentModel>
    {
        private readonly IGenericRepository<DepartmentModel> _genericRepository;

        public GetDepartmentByIdQueryHandler(IGenericRepository<DepartmentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<DepartmentModel> Handle(GetDepartmentByIdQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetByIdAsync(request.Id);
        }
    }

}

