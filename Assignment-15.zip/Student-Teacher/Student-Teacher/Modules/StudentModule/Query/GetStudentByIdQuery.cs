﻿using MediatR;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.StudentModule.Query
{
    public class GetStudentByIdQuery : IRequest<StudentModel>
    {
        public Guid Id { get; set; }
    }

    public class GetStudentByIdQueryHandler : IRequestHandler<GetStudentByIdQuery, StudentModel>
    {
        private readonly IGenericRepository<StudentModel> _genericRepository;

        public GetStudentByIdQueryHandler(IGenericRepository<StudentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<StudentModel> Handle(GetStudentByIdQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetByIdAsync(request.Id);
        }
    }

}
