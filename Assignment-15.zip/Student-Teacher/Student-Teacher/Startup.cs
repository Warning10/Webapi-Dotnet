﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Student_Teacher.Extensions;
using Student_Teacher.Interfaces;
using Student_Teacher.Repository;
using System.Text;

namespace Student_Teacher
{
	public class Startup(IConfiguration configuration)
	{
		public IConfiguration Configuration { get; } = configuration;

		public void ConfigureServices(IServiceCollection services)
		{
			services.AddApplicationLayer();
			services.ConfigureCors();
			services.CongigureSQLConnection(Configuration);
			services.AddControllers();
			services.AddSwaggerGen(c =>
			{
				c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
				{
					In = ParameterLocation.Header,
					Description = "Please insert JWT with Bearer into field",
					Name = "Authorization",
					Type = SecuritySchemeType.ApiKey,
					BearerFormat = "JWT",
					Scheme = "Bearer"
				});

				c.AddSecurityRequirement(new OpenApiSecurityRequirement
	{
		{
			new OpenApiSecurityScheme
			{
				Reference = new OpenApiReference
				{
					Type = ReferenceType.SecurityScheme,
					Id = "Bearer"
				}
			},
			Array.Empty<string>()
		}
	});
			});


			// JWT Authentication
			var key = Encoding.UTF8.GetBytes(Configuration["JwtSettings:Key"]);
			services.AddAuthentication(x =>
			{
				x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
				x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
			}).AddJwtBearer(x =>
			{
				x.RequireHttpsMetadata = false;
				x.SaveToken = true;
				x.TokenValidationParameters = new TokenValidationParameters
				{
					ValidateIssuerSigningKey = true,
					IssuerSigningKey = new SymmetricSecurityKey(key),
					ValidateIssuer = true,
					ValidateAudience = true,
					ValidIssuer = Configuration["JwtSettings:Issuer"],
					ValidAudience = Configuration["JwtSettings:Audience"]
				};
			});

			// Dependency Injection
			services.AddScoped<IJwtTokenService, JwtTokenService>();
			services.AddScoped<IUserRepository, UserRepository>();


		}
		public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
		{
			if (env.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
				app.UseSwagger();
				app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Student-Teacher API v1"));
			}

			app.UseRouting();

			app.UseAuthentication();  // Enable authentication
			app.UseAuthorization();

			app.UseEndpoints(endpoints =>
			{
				endpoints.MapControllers();
			});

		}
	}
}
