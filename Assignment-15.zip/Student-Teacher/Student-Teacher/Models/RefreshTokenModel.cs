﻿namespace Student_Teacher.Models
{
	public class RefreshTokenModel
	{
		public string Token { get; set; }
		public string RefreshToken { get; set; }
	}

}
