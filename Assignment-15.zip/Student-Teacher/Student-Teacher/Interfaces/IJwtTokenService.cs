﻿using System.Security.Claims;

namespace Student_Teacher.Interfaces
{
	public interface IJwtTokenService
	{
		string GenerateToken(IEnumerable<Claim> claims);
		string GenerateRefreshToken();
		ClaimsPrincipal GetPrincipalFromExpiredToken(string token);
	}
}
