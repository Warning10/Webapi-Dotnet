﻿using Student_Teacher.Models;

namespace Student_Teacher.Interfaces
{
	public interface IUserRepository
	{
		User GetUserByUsername(string username);
		void UpdateUser(User user);
	}
}
