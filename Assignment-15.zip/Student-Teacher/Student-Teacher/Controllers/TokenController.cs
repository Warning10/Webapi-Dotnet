﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Student_Teacher.Interfaces;
using Student_Teacher.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace Student_Teacher.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class TokenController : ControllerBase
	{
		private readonly IJwtTokenService _jwtTokenService;
		private readonly IUserRepository _userRepository;

		public TokenController(IJwtTokenService jwtTokenService, IUserRepository userRepository)
		{
			_jwtTokenService = jwtTokenService;
			_userRepository = userRepository;
		}

		[HttpPost("authenticate")]
		public IActionResult Authenticate([FromBody] LoginModel model)
		{
			var user = _userRepository.GetUserByUsername(model.Username);
			if (user == null || user.PasswordHash != model.Password) // Add proper password hashing comparison
			{
				return Unauthorized("Invalid credentials");
			}

			var claims = new[]
			{
			new Claim(ClaimTypes.Name, user.Username),
			new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
		};

			var token = _jwtTokenService.GenerateToken(claims);
			var refreshToken = _jwtTokenService.GenerateRefreshToken();

			user.RefreshToken = refreshToken;
			user.RefreshTokenExpiryTime = DateTime.UtcNow.AddDays(7); // Refresh token valid for 7 days
			_userRepository.UpdateUser(user);

			return Ok(new TokenModel
			{
				Token = token,
				RefreshToken = refreshToken
			});
		}

		[HttpPost("refresh")]
		public IActionResult Refresh([FromBody] RefreshTokenModel model)
		{
			var principal = _jwtTokenService.GetPrincipalFromExpiredToken(model.Token);
			var username = principal.Identity.Name;
			var user = _userRepository.GetUserByUsername(username);

			if (user == null || user.RefreshToken != model.RefreshToken || user.RefreshTokenExpiryTime <= DateTime.UtcNow)
			{
				return Unauthorized("Invalid refresh token");
			}

			var newJwtToken = _jwtTokenService.GenerateToken(principal.Claims);
			var newRefreshToken = _jwtTokenService.GenerateRefreshToken();

			user.RefreshToken = newRefreshToken;
			user.RefreshTokenExpiryTime = DateTime.UtcNow.AddMinutes(2);
			_userRepository.UpdateUser(user);

			return Ok(new TokenModel
			{
				Token = newJwtToken,
				RefreshToken = newRefreshToken
			});
		}

		[Authorize]
		[HttpPost("revoke")]
		public IActionResult Revoke()
		{
			var username = User.Identity.Name;
			var user = _userRepository.GetUserByUsername(username);

			if (user == null) return BadRequest();

			user.RefreshToken = null;
			_userRepository.UpdateUser(user);

			return NoContent();
		}
	}

}
