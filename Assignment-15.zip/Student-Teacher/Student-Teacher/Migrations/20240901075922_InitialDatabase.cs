﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Student_Teacher.Migrations
{
    /// <inheritdoc />
    public partial class InitialDatabase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Departments",
                columns: table => new
                {
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DeptName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departments", x => x.DeptId);
                });

            migrationBuilder.CreateTable(
                name: "StudentModel",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EnrollmentDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Grade = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StudentModel", x => x.Id);
                    table.ForeignKey(
                        name: "FK_StudentModel_Departments_DeptId",
                        column: x => x.DeptId,
                        principalTable: "Departments",
                        principalColumn: "DeptId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TeacherModel",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    HireDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Position = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TeacherModel", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TeacherModel_Departments_DeptId",
                        column: x => x.DeptId,
                        principalTable: "Departments",
                        principalColumn: "DeptId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Departments",
                columns: new[] { "DeptId", "Created", "DeptName", "Updated" },
                values: new object[,]
                {
                    { new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(7064), "Computer", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(7065) },
                    { new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(7071), "Mechanical", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(7071) },
                    { new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(7068), "Information Technology", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(7069) },
                    { new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(7073), "Civil", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(7074) },
                    { new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(7076), "Production", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(7076) }
                });

            migrationBuilder.InsertData(
                table: "StudentModel",
                columns: new[] { "Id", "Created", "DateOfBirth", "DeptId", "Email", "EnrollmentDate", "FirstName", "Gender", "Grade", "LastName", "Updated" },
                values: new object[,]
                {
                    { new Guid("58ab9b93-bc00-4e7e-8936-133327f68150"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6532), new DateTime(2000, 11, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "ethan.davis@example.com", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6531), "Ethan", "Male", "10th", "Davis", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6532) },
                    { new Guid("82ad3080-ffe5-4d13-b2e8-02822defe4d0"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6525), new DateTime(2002, 3, 9, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "diana.brown@example.com", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6524), "Diana", "Female", "8th", "Brown", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6526) },
                    { new Guid("c9ce4f80-62da-4cbb-975e-5df21e759441"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6520), new DateTime(2005, 12, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "charlie.williams@example.com", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6519), "Charlie", "Non-Binary", "5th", "Williams", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6520) },
                    { new Guid("d91b1abb-2dd2-4572-8bd1-53a053e9122c"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6504), new DateTime(2010, 7, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "bob.johnson@example.com", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6503), "Bob", "Male", "1st", "Johnson", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6504) },
                    { new Guid("ec160c46-3258-42f6-810c-aebdd1265233"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6496), new DateTime(2015, 5, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "alice.smith@example.com", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6490), "Alice", "Female", "Nursery", "Smith", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6497) }
                });

            migrationBuilder.InsertData(
                table: "TeacherModel",
                columns: new[] { "Id", "Created", "DeptId", "Email", "FirstName", "Gender", "HireDate", "LastName", "Position", "Updated" },
                values: new object[,]
                {
                    { new Guid("180cc0e2-03ff-47e6-833a-fb62d421ff28"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6882), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "amit.deshmukh@example.com", "Amit", "Male", new DateTime(2010, 8, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Deshmukh", "Math Teacher", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6883) },
                    { new Guid("873b9749-49c7-49c0-a13d-c5f79d69e138"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6904), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "vikram.shinde@example.com", "Vikram", "Male", new DateTime(2022, 11, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Shinde", "Physical Education Teacher", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6905) },
                    { new Guid("c332a467-94d2-4ae1-8135-efacbf3f4bae"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6894), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "rajesh.kulkarni@example.com", "Rajesh", "Male", new DateTime(2018, 6, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "Kulkarni", "History Teacher", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6895) },
                    { new Guid("defa05ba-998d-4def-af27-0338d931c681"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6900), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "pooja.jadhav@example.com", "Pooja", "Female", new DateTime(2020, 3, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "Jadhav", "English Teacher", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6901) },
                    { new Guid("e522a773-1dbf-422f-a271-e6b6d7983a0c"), new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6890), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "snehal.patil@example.com", "Snehal", "Female", new DateTime(2015, 1, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "Patil", "Science Teacher", new DateTime(2024, 9, 1, 7, 59, 20, 549, DateTimeKind.Utc).AddTicks(6890) }
                });

            migrationBuilder.CreateIndex(
                name: "IX_StudentModel_DeptId",
                table: "StudentModel",
                column: "DeptId");

            migrationBuilder.CreateIndex(
                name: "IX_TeacherModel_DeptId",
                table: "TeacherModel",
                column: "DeptId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "StudentModel");

            migrationBuilder.DropTable(
                name: "TeacherModel");

            migrationBuilder.DropTable(
                name: "Departments");
        }
    }
}
