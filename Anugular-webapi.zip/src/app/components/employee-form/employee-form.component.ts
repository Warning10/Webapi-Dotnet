import { Component, inject } from '@angular/core';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpService } from '../../http.service';
import { IEmployee } from '../../interfaces/employee';


@Component({
  selector: 'app-employee-form',
  standalone: true,
  imports: [MatInputModule, MatButtonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './employee-form.component.html',
  styleUrl: './employee-form.component.css'
})
export class EmployeeFormComponent {
formbuilder=inject(FormBuilder);
httpService=inject(HttpService);
router=inject(Router);
route=inject(ActivatedRoute);
employeeForm=this.formbuilder.group({
  firstName:['',[Validators.required]],
  lastName:['',[Validators.required]],
  email:['',[Validators.required, Validators.email]],
  gender:['',[Validators.required]],
  address:['',[Validators.required]],
  designation:['',[Validators.required]],
  dateOfBirth:['',[Validators.required]],
  dateOfJoining:['',[Validators.required]],
  isActive:['',[Validators.required]],
  // created:['',[Validators.required]],
  // updated:['',[Validators.required]],

});
employeeId!:number;
isEdit = false;
ngOnInit(){
  this.employeeId=this.route.snapshot.params['id'];
  if(this.employeeId){
    this.isEdit=true;
    this.httpService.getEmployee(this.employeeId).subscribe(result=>{
      console.log(result);
      this.employeeForm.patchValue(result);
    })
  }
}

save(){
  console.log(this.employeeForm.value);
  const employee :IEmployee = {
    firstName: this.employeeForm.value.firstName!,
    lastName: this.employeeForm.value.lastName!,
    email: this.employeeForm.value.email!,
    gender: this.employeeForm.value.gender!,
    address: this.employeeForm.value.address!,
    designation: this.employeeForm.value.designation!,
    dateOfBirth: this.employeeForm.value.dateOfBirth!,
    dateOfJoining: this.employeeForm.value.dateOfJoining!,
    isActive: this.employeeForm.value.isActive!
  };
  if(this.isEdit){
    this.httpService.updateEmployee(this.employeeId,employee).subscribe(()=>{
      console.log('Employee Updated successfully');
      this.router.navigateByUrl("/employee-list")
    });
  
  }
  else{
  this.httpService.createEmployee(employee).subscribe(()=>{
    console.log('Employee created successfully');
    this.router.navigateByUrl("/employee-list")
  });
  }
}
}
