export interface IEmployee {
    id?: number;
    firstName: string;
    lastName: string;
    email: string;
    gender: string;
    address: string;
    designation: string;
    dateOfBirth: string;
    dateOfJoining: string;
    isActive: string;
    created?: string;
    updated?: string;
}