import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { IEmployee } from '../../interfaces/employee';
import { EmployeeDataService } from '../../services/employee-data.service';
import { Router } from '@angular/router';
import * as bootstrap from 'bootstrap';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employees: IEmployee[] = [];
  selectedEmployee?: IEmployee;

  constructor(
    private employeeService: EmployeeDataService,
    private toastr: ToastrService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadEmployees();
  }

  loadEmployees(): void {
    this.employeeService.getAllEmployee().subscribe({
      next: (data: IEmployee[]) => {
        this.employees = data;
      },
      error: (err) => {
        this.toastr.error('Failed to load employees', 'Error');
      }
    });
  }

  openViewModal(employee: IEmployee): void {
    this.selectedEmployee = employee;
    const viewModal = new bootstrap.Modal(document.getElementById('viewModal')!);
    viewModal.show();
  }

  openDeleteModal(employee: IEmployee): void {
    this.selectedEmployee = employee;
    const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal')!);
    deleteModal.show();
  }

  confirmDelete(): void {
    if (this.selectedEmployee?.id) {
      this.employeeService.deleteEmployee(this.selectedEmployee.id).subscribe({
        next: () => {
          this.toastr.success('Employee deleted successfully', 'Success');
          this.loadEmployees();
        },
        error: (err) => {
          this.toastr.error('Failed to delete employee', 'Error');
        }
      });
    }
    const deleteModal = bootstrap.Modal.getInstance(document.getElementById('deleteModal')!);
    deleteModal?.hide();
  }

  editEmployee(id: number): void {
    this.router.navigate([`/employee-form/${id}`]);
  }

  navigateToAddEmployee(): void {
    this.router.navigate(['/employee-form']);
  }
}
