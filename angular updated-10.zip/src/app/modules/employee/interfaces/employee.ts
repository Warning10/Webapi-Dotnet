export interface IEmployee {
    id?: number;
    name: string;
    email: string;
    gender: string;
    phone: string;
    address: string;
    designation: string;
}