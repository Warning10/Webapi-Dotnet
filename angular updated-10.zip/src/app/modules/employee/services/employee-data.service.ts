import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IEmployee } from '../interfaces/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeDataService {
  private apiUrl = "https://localhost:7162";

  constructor(private http: HttpClient) { }

  getAllEmployee(): Observable<IEmployee[]> {
    return this.http.get<IEmployee[]>(`${this.apiUrl}/api/EmployeeGenericCqrs/all`);
  }

  createEmployee(employee: IEmployee): Observable<IEmployee> {
    return this.http.post<IEmployee>(`${this.apiUrl}/api/EmployeeGenericCqrs/create`, employee);
  }

  getEmployee(employeeId: number): Observable<IEmployee> {
    return this.http.get<IEmployee>(`${this.apiUrl}/api/EmployeeGenericCqrs/byid/${employeeId}`);
  }

  updateEmployee(employeeId: number, employee: IEmployee): Observable<IEmployee> {
    return this.http.put<IEmployee>(`${this.apiUrl}/api/EmployeeGenericCqrs/update/${employeeId}`, employee);
  }

  deleteEmployee(employeeId: number): Observable<IEmployee> {
    return this.http.delete<IEmployee>(`${this.apiUrl}/api/EmployeeGenericCqrs/delete/${employeeId}`);
  }
}
