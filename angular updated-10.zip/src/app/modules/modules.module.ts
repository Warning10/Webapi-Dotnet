import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeModule } from './employee/employee.module';
import { ReactiveFormsModule } from '@angular/forms';
import { DepartmentListComponent } from './department/components/department-list/department-list.component';
import { DepartmentFormComponent } from './department/components/department-form/department-form.component'; // Import ReactiveFormsModule



@NgModule({
  declarations: [
    DepartmentListComponent,
    DepartmentFormComponent
  ],
  imports: [
    CommonModule,
    EmployeeModule,
    ReactiveFormsModule
  ],
  exports: [
    EmployeeModule,
    DepartmentListComponent,
    DepartmentFormComponent
  
  ],
  
})
export class ModulesModule { }
