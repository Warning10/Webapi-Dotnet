import { Component } from "@angular/core";

@Component({
    selector: 'employee',
    templateUrl: './employee.component.html',
    styleUrl: './employee.component.css'
})
export class EmployeeComponent{
    //interpolation
    name = 'Atharva';
    book : any = {
        title: 'Aress',
        Author: 'Anushka Chavan',
        isbn: 123
    }

    //Property binding
    imageSource: string = "https://rb.gy/0eum05"
    inputValue: string = "Hello Atharva"
}