import { Routes } from '@angular/router';
import { HomePageComponent } from './components/home-page/home-page.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';

// Define the routes array
export const routes: Routes = [
    { path: '', component: HomePageComponent }, // Route to HomePageComponent for default path
    { path: 'contactus', component: ContactUsComponent }, // Route to ContactUsComponent
    { path: 'login', component: LoginComponent }, // Route to LoginComponent
    { path: 'register', component: RegistrationComponent }, // Route to RegistrationComponent
];
