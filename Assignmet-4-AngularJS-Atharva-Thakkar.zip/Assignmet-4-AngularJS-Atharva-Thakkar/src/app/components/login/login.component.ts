import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  
  // Method to handle form submission
  onSubmit(dataEntered: NgForm) {
    // Check if the form is valid
    if (dataEntered.valid) {
      // If valid, show success message
      alert("Login Successfully!");
    } else {
      // If not valid, show error message
      alert("**Data not submitted\n Please fill required fields!!");
    }
  }
}
