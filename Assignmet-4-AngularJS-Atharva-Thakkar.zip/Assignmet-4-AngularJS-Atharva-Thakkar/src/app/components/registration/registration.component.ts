import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Component({
  selector: 'app-registration',
  standalone: true, // Standalone component
  imports: [CommonModule, FormsModule], // Import necessary modules
  templateUrl: './registration.component.html', // Template file
  styleUrl: './registration.component.scss' // Stylesheet file
})
export class RegistrationComponent {
  confirmPasswordValue: string = ""; // Initialize confirm password variable

  registerForm!: FormGroup; // Declare registerForm as FormGroup
  submitted: boolean = false; // Flag to track form submission

  // Function to handle form submission
  onSubmit(dataEntered: NgForm) {
    const formData = dataEntered.value; // Extract form data

    // Check if password and confirm password match
    if (formData.confirmPassword != formData.password) {
      alert("Password and Confirm Password do not match");
    } else if (dataEntered.valid) {
      alert("Successfully registered!!");
    } else {
      alert("**Data not submitted\n Please fill required fields!!");
    }
  }
}
