import { Component } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-contact-us',
  standalone: true,
  imports: [FontAwesomeModule, FormsModule, CommonModule],
  templateUrl: './contact-us.component.html',
  styleUrl: './contact-us.component.scss'
})

export class ContactUsComponent {

  // Method to handle form submission
  onSubmit(dataEntered: NgForm) {
    // Check if the form is valid
    if (dataEntered.valid) {
      // If valid, show success message
      alert("Data submitted!!");
    } else {
      // If not valid, show error message
      alert("**Data not submitted\n Please fill required fields!!");
    }
  }
}
