import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { UserDataService } from '../../services/user-data.service';
import { CommonModule } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormControl, FormGroup, Validators, ReactiveFormsModule, FormsModule, NgForm } from '@angular/forms';

import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [RouterLink, CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './home-page.component.html',
  styleUrl: './home-page.component.scss'
})
export class HomePageComponent {
  public posts: any;

  postForm: FormGroup = new FormGroup({});

  currentPost: any = { 
    id: 0,
    title: '',
    body: ''
  };

  constructor(private userDataService: UserDataService, private toastr: ToastrService, private titleService: Title) {

  }

  public ngOnInit(): void {
    this.userDataService.getPost().subscribe(posts => {
      this.posts = posts;
    });
  }


  newPost(form: NgForm) {

    this.userDataService.addPost(form.value).subscribe((res) => {

      this.posts.push(res)
      this.toastr.success("Post Added Successfully")
      form.resetForm();
    },
      (err) => {
        this.toastr.success("Something Went Wrong")
      });



  }

  // this.userDataService.getPost().subscribe({
  //   next: response => {

  //   },
  //   error: error => {

  //   },
  //   complete:  =>{

  //   }

  // });

  setCurrentPost(id: any) {
    this.currentPost = this.posts.find((post: any) => post.id === id)
  }

  viewPost(id: any) {

    this.titleService.setTitle(this.currentPost.title);

  }

  editPost(posts: any) {

    this.userDataService.editPost(this.currentPost).subscribe((res) => {

      this.toastr.success("Post Updated Successfully")
    }, (err) => {
      this.toastr.success("Something Went Wrong")
    })

  }

  deletePost() {

    this.userDataService.deletePost(this.currentPost.id).subscribe((res) => {

      this.posts = this.posts.filter((post: any) => post.id !== this.currentPost.id)

      this.toastr.success("Post Deleted Successfully")

    }, (err) => {
      this.toastr.success("Something Went Wrong")
    })

  }

}
