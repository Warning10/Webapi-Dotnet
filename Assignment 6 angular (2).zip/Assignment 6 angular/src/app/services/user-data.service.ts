import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserDataService {


  private josn_url = 'http://localhost:3000/Post'


  constructor(private http: HttpClient) { }

  public getPost(): Observable<any> {
    return this.http.get(this.josn_url);

  }

  addPost(post: any): Observable<any> {

    const json_data = JSON.stringify(post)

    return this.http.post(this.josn_url, json_data); //localhost:3000/Post

  }

  checkUser(user: any) {

    const url = 'http://localhost:3000/User?username=' + user.username

    return this.http.get(url)

  }

  deletePost(id: any) {
    return this.http.delete(this.josn_url + '/' + id)//localhost:3000/Posts/1234  
  }

  editPost(post: any) {
    const json_data = JSON.stringify(post)
    return this.http.put(this.josn_url + '/' + post.id, json_data) //localhost:3000/Posts/1234 {title:"thva",body:""}
  }

}