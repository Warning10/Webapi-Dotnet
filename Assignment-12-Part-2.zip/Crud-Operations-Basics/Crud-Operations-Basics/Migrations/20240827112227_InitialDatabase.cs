﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Crud_Operations_Basics.Migrations
{
    /// <inheritdoc />
    public partial class InitialDatabase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Departments",
                columns: table => new
                {
                    DeptId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DeptName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departments", x => x.DeptId);
                });

            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Designation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeptId = table.Column<int>(type: "int", nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DateOfJoining = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Departments",
                columns: new[] { "DeptId", "Created", "DeptName", "Updated" },
                values: new object[,]
                {
                    { 1, new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9316), "Human Resources", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9316) },
                    { 2, new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9318), "Information Technology", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9319) },
                    { 3, new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9320), "Finance", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9320) },
                    { 4, new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9322), "Marketing", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9322) },
                    { 5, new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9323), "Operations", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9324) }
                });

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "Id", "Address", "Created", "DateOfBirth", "DateOfJoining", "DeptId", "Designation", "Email", "Gender", "IsActive", "Name", "Updated" },
                values: new object[,]
                {
                    { 1, "123 Pune Road, Pune, Maharashtra", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9049), new DateTime(1980, 6, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2010, 3, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 1, "HR Manager", "amit.deshmukh@example.com", "M", true, "Amit Deshmukh", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9049) },
                    { 2, "456 Mumbai Lane, Mumbai, Maharashtra", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9053), new DateTime(1990, 7, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2015, 5, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), 2, "Software Engineer", "sneha.patil@example.com", "F", true, "Sneha Patil", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9053) },
                    { 3, "789 Nagpur Street, Nagpur, Maharashtra", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9055), new DateTime(1985, 12, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2018, 11, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 3, "Finance Analyst", "ravi.kale@example.com", "M", true, "Ravi Kale", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9056) },
                    { 4, "321 Aurangabad Road, Aurangabad, Maharashtra", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9058), new DateTime(1992, 3, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2019, 2, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 4, "Marketing Executive", "pooja.shinde@example.com", "F", true, "Pooja Shinde", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9059) },
                    { 5, "654 Nashik Lane, Nashik, Maharashtra", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9061), new DateTime(1978, 9, 28, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2012, 6, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), 5, "Operations Manager", "suresh.gore@example.com", "M", true, "Suresh Gore", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9065) },
                    { 6, "987 Solapur Street, Solapur, Maharashtra", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9067), new DateTime(1987, 8, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2016, 4, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), 1, "HR Specialist", "anita.joshi@example.com", "F", true, "Anita Joshi", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9068) },
                    { 7, "345 Satara Road, Satara, Maharashtra", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9070), new DateTime(1982, 2, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2017, 7, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 2, "IT Consultant", "ajay.jadhav@example.com", "M", true, "Ajay Jadhav", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9070) },
                    { 8, "678 Thane Avenue, Thane, Maharashtra", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9073), new DateTime(1991, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2014, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 3, "Senior Finance Analyst", "meera.desai@example.com", "F", true, "Meera Desai", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9074) },
                    { 9, "987 Jalgaon Road, Jalgaon, Maharashtra", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9076), new DateTime(1986, 4, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2011, 8, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), 4, "Marketing Manager", "kunal.naik@example.com", "M", true, "Kunal Naik", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9076) },
                    { 10, "321 Pimpri Chinchwad Road, Pimpri Chinchwad, Maharashtra", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9078), new DateTime(1995, 11, 11, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2020, 3, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 5, "Operations Executive", "prachi.rane@example.com", "F", true, "Prachi Rane", new DateTime(2024, 8, 27, 11, 22, 26, 826, DateTimeKind.Utc).AddTicks(9079) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Departments");

            migrationBuilder.DropTable(
                name: "Employees");
        }
    }
}
