﻿using Crud_Operations_Basics.Models;
using Crud_Operations_Basics.Models.Dto;
using FluentValidation;

namespace Crud_Operations_Basics.Utils.Validators
{
    public class DepartmentValidators : AbstractValidator<DepartmentDto>
    {
        public DepartmentValidators()
        {
            RuleFor(x => x.DeptName)
                .NotNull()
                .WithMessage("Department name cannot be null.")
                .NotEmpty()
                .WithMessage("Department name is required.")
                .Length(1, 100)
                .WithMessage("Department name must be between 1 and 100 characters.");

/*            RuleFor(x => x.Created)
                .NotNull()
                .WithMessage("Creation date cannot be null.")
                .NotEmpty()
                .WithMessage("Creation date is required.");

			RuleFor(x => x.Updated)
				 .NotNull()
				 .WithMessage("Updated date cannot be null.")
				 .NotEmpty()
				 .WithMessage("Updated date is required.");*/
		}
    }
}