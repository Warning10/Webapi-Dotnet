﻿using System.ComponentModel.DataAnnotations;

namespace Crud_Operations_Basics.Models
{
    public class DepartmentModel
    {
        [Key]
        public int DeptId { get; set; }

        //[Required(ErrorMessage = "Department name is required.")]
        //[StringLength(100, MinimumLength = 1, ErrorMessage = "Department name must be between 1 and 100 characters.")]
        public string DeptName { get; set; }

        public DateTime Created { get; set; } = DateTime.UtcNow;

        public DateTime Updated { get; set; } = DateTime.UtcNow;

	}
}
