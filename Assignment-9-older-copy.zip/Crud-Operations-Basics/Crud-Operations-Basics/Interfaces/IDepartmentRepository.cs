﻿using Crud_Operations_Basics.Models;
using Crud_Operations_Basics.Models.Dto;
using Microsoft.AspNetCore.JsonPatch;

namespace Crud_Operations_Basics.Interfaces
{
    public interface IDepartmentRepository
    {
        Task<List<DepartmentModel>> GetAllDepartmentsAsync();
        Task<DepartmentModel> GetDepartmentsByIdAsync(int departmentId);
        Task<int> AddDepartmentsAsync(DepartmentDto departmentDto);
        Task UpdateDepartmentsAsync(int departmentId, DepartmentDto departmentDto);
        Task UpdateDepartmentsPatchAsync(int departmentId, JsonPatchDocument<DepartmentDto> patchDocument);
        Task<bool> DeleteDepartmentsAsync(int departmentId);
    }
}
