﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using Crud_Operations_Basics.Models.Dto;
using Crud_Operations_Basics.Utils.Validators;
using FluentValidation.Results;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;

namespace Crud_Operations_Basics.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeGenericController : ControllerBase
    {
        private readonly IGenericRepository<EmployeeModel> _employeeGenericRepository;

        public EmployeeGenericController(IGenericRepository<EmployeeModel> employeeGenericRepository)
        {
            _employeeGenericRepository = employeeGenericRepository;
        }

        [HttpGet("all")]
        public async Task<IActionResult> GetAllEmployees()
        {
            var result = await _employeeGenericRepository.GetAllAsync();
            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetEmployeesById([FromRoute] int id)
        {

            var employee = await _employeeGenericRepository.GetByIdAsync(id);
            if (employee == null)
            {
                return NotFound();
            }
            return Ok(employee);
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddNewEmployee([FromBody] EmployeeDto employeeDto)
        {
			ValidationResult validationResult = new EmployeeValidators().Validate(employeeDto);
			if (validationResult.IsValid)
            {
				var employeeModel = new EmployeeModel
				{
					FirstName = employeeDto.FirstName,
					LastName = employeeDto.LastName,
					Email = employeeDto.Email,
					Gender = employeeDto.Gender,
					Address = employeeDto.Address,
					Designation = employeeDto.Designation,
					DeptId = employeeDto.DeptId,
					DateOfBirth = employeeDto.DateOfBirth,
					DateOfJoining = employeeDto.DateOfJoining,
					IsActive = employeeDto.IsActive,
					Created = DateTime.UtcNow,
					Updated = DateTime.UtcNow
				};


				var id = await _employeeGenericRepository.AddAsync(employeeModel);
				return Ok(id);
			}
			return BadRequest(validationResult.Errors.ToList()[0].ErrorMessage);

		}


		[HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateEmployee([FromBody] EmployeeDto employeeDto, [FromRoute] int id)
        {
			ValidationResult validationResult = new EmployeeValidators().Validate(employeeDto);
            if (validationResult.IsValid)
            {
                var employeeModel = new EmployeeModel
                {
                    Id = id,
                    FirstName = employeeDto.FirstName,
                    LastName = employeeDto.LastName,
                    Email = employeeDto.Email,
                    Gender = employeeDto.Gender,
                    Address = employeeDto.Address,
                    Designation = employeeDto.Designation,
                    DeptId = employeeDto.DeptId,
                    DateOfBirth = employeeDto.DateOfBirth,
                    DateOfJoining = employeeDto.DateOfJoining,
                    IsActive = employeeDto.IsActive,
                    Updated = DateTime.UtcNow
                };
                await _employeeGenericRepository.UpdateAsync(id, employeeModel);
                return Ok();
            }
			return BadRequest(validationResult.Errors.ToList()[0].ErrorMessage);

		}

		[HttpPatch("patch/update/{id}")]
        public async Task<IActionResult> UpdateEmployeePatch([FromBody] JsonPatchDocument employeeModel, [FromRoute] int id)
        {
            await _employeeGenericRepository.UpdatePatchAsync(id, employeeModel);
            return Ok();
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteEmployee([FromRoute] int id)
        {
            return Ok(await _employeeGenericRepository.DeleteAsync(id));
        }

    }
}
