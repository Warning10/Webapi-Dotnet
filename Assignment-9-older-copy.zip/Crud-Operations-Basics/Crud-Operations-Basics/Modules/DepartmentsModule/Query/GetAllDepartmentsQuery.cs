﻿using Crud_Operations_Basics.Interfaces;
using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Query
{
    public class GetAllDepartmentsQuery : IRequest<List<Models.DepartmentModel>> { }

    public class GetAllDepartmentsQueryHandler : IRequestHandler<GetAllDepartmentsQuery, List<Models.DepartmentModel>>
    {
        private readonly IGenericRepository<Models.DepartmentModel> _departmentservice;

        public GetAllDepartmentsQueryHandler(IGenericRepository<Models.DepartmentModel> departmentservice)
        {
            _departmentservice = departmentservice;
        }
        public async Task<List<Models.DepartmentModel>> Handle(GetAllDepartmentsQuery request, CancellationToken cancellationToken)
        {
            return await _departmentservice.GetAllAsync();
        }
    }
}
