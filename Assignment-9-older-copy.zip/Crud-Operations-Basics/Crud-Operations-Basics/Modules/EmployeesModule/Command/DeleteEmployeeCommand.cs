﻿using Crud_Operations_Basics.Interfaces;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Command
{
    public class DeleteEmployeeCommand : EmployeeCommand
    {
        public int Id { get; set; }
    }
    public class DeleteEmployeeCommandHandler : IRequestHandler<DeleteEmployeeCommand, bool>
    {
        private readonly IGenericRepository<Models.EmployeeModel> _genericRepository;
        public DeleteEmployeeCommandHandler(IGenericRepository<Models.EmployeeModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(DeleteEmployeeCommand request, CancellationToken cancellationToken)
        {
            var existingEmployee = await _genericRepository.GetByIdAsync(request.Id);
            if (existingEmployee == null)
            {
                return false;
            }
            return await _genericRepository.DeleteAsync(request.Id);

        }

    }

}
