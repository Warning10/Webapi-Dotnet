﻿using Crud_Operations_Basics.Modules.EmployeesModule.Command;
using Crud_Operations_Basics.Modules.EmployeesModule.Query;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Crud_Operations_Basics.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeGenericCqrsController : ControllerBase
    {
        private readonly ISender _mediatR;

        public EmployeeGenericCqrsController(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        [HttpGet("all")]
        public async Task<List<Models.EmployeeModel>> GetAllEmployees()
        {
            var result = await _mediatR.Send(new GetAllEmployeesQuery());
            return result;
        }

        [HttpGet("byid/{id}")]
        public async Task<Models.EmployeeModel> GetEmployeeById([FromRoute]int id)
        {
            var result = await _mediatR.Send(new GetEmployeeByIdQuery() {Id = id });
            return result;
        }

        [HttpPost("create")]
        public async Task<object> CreateEmployee([FromBody] CreateEmployeeCommand createEmployeeCommand)
        {
            return await _mediatR.Send(createEmployeeCommand);

        }

        [HttpPut("update/{id}")]
        public async Task<object> UpdateEmployee([FromBody] EmployeeCommand employeeCommand, [FromRoute] int id)
        {
            var response = await _mediatR.Send(new UpdateEmployeeCommand() 
            {
                Id = id,
                FirstName = employeeCommand.FirstName,
                LastName = employeeCommand.LastName,
                Email = employeeCommand.Email,
                Gender = employeeCommand.Gender,
                Address = employeeCommand.Address,
                Designation = employeeCommand.Designation,
                //DeptId = employeeCommand.DeptId,
                DateOfBirth = employeeCommand.DateOfBirth,
                DateOfJoining = employeeCommand.DateOfJoining,
                IsActive = employeeCommand.IsActive,

            }
            
            );
            return response;
        }

        [HttpDelete("delete/{id}")]
        public async Task<object> DeleteEmployee([FromRoute]int id)
        {
            return await _mediatR.Send(new DeleteEmployeeCommand() { Id = id });
        }


    }



}
