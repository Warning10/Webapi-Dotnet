﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Crud_Operations_Basics.Migrations
{
    /// <inheritdoc />
    public partial class InitialDatabase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Departments",
                columns: table => new
                {
                    DeptId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DeptName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departments", x => x.DeptId);
                });

            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Designation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DateOfJoining = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Departments",
                columns: new[] { "DeptId", "Created", "DeptName", "Updated" },
                values: new object[,]
                {
                    { 1, new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9633), "Human Resources", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9633) },
                    { 2, new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9635), "Information Technology", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9636) },
                    { 3, new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9637), "Finance", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9638) },
                    { 4, new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9639), "Marketing", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9639) },
                    { 5, new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9641), "Operations", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9641) }
                });

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "Id", "Address", "Created", "DateOfBirth", "DateOfJoining", "Designation", "Email", "FirstName", "Gender", "IsActive", "LastName", "Updated" },
                values: new object[,]
                {
                    { 1, "123 Pune Road, Pune, Maharashtra", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9430), new DateTime(1980, 6, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2010, 3, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "HR Manager", "amit.deshmukh@example.com", "Amit", "M", true, "Deshmukh", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9431) },
                    { 2, "456 Mumbai Lane, Mumbai, Maharashtra", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9435), new DateTime(1990, 7, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2015, 5, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "Software Engineer", "sneha.patil@example.com", "Sneha", "F", true, "Patil", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9435) },
                    { 3, "789 Nagpur Street, Nagpur, Maharashtra", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9438), new DateTime(1985, 12, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2018, 11, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Finance Analyst", "ravi.kale@example.com", "Ravi", "M", true, "Kale", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9438) },
                    { 4, "321 Aurangabad Road, Aurangabad, Maharashtra", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9441), new DateTime(1992, 3, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2019, 2, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Marketing Executive", "pooja.shinde@example.com", "Pooja", "F", true, "Shinde", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9441) },
                    { 5, "654 Nashik Lane, Nashik, Maharashtra", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9443), new DateTime(1978, 9, 28, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2012, 6, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "Operations Manager", "suresh.gore@example.com", "Suresh", "M", true, "Gore", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9443) },
                    { 6, "987 Solapur Street, Solapur, Maharashtra", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9446), new DateTime(1987, 8, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2016, 4, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "HR Specialist", "anita.joshi@example.com", "Anita", "F", true, "Joshi", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9446) },
                    { 7, "345 Satara Road, Satara, Maharashtra", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9448), new DateTime(1982, 2, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2017, 7, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "IT Consultant", "ajay.jadhav@example.com", "Ajay", "M", true, "Jadhav", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9449) },
                    { 8, "678 Thane Avenue, Thane, Maharashtra", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9451), new DateTime(1991, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2014, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Senior Finance Analyst", "meera.desai@example.com", "Meera", "F", true, "Desai", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9451) },
                    { 9, "987 Jalgaon Road, Jalgaon, Maharashtra", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9454), new DateTime(1986, 4, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2011, 8, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), "Marketing Manager", "kunal.naik@example.com", "Kunal", "M", true, "Naik", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9454) },
                    { 10, "321 Pimpri Chinchwad Road, Pimpri Chinchwad, Maharashtra", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9456), new DateTime(1995, 11, 11, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2020, 3, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Operations Executive", "prachi.rane@example.com", "Prachi", "F", true, "Rane", new DateTime(2024, 8, 20, 16, 46, 36, 678, DateTimeKind.Utc).AddTicks(9457) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Departments");

            migrationBuilder.DropTable(
                name: "Employees");
        }
    }
}
