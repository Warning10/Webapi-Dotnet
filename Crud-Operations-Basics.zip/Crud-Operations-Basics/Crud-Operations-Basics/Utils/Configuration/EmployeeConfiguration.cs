﻿using Crud_Operations_Basics.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Crud_Operations_Basics.Utils.Configuration
{
    public class EmployeeConfiguration : IEntityTypeConfiguration<EmployeeModel>
    {
        public void Configure(EntityTypeBuilder<EmployeeModel> builder)
        {
            builder.HasData(
                    new EmployeeModel
                    {
                        Id = 1,
                        FirstName = "Amit",
                        LastName = "Deshmukh",
                        Email = "amit.deshmukh@example.com",
                        Gender = "M",
                        Address = "123 Pune Road, Pune, Maharashtra",
                        Designation = "HR Manager",
                        //DeptId = 1,
                        DateOfBirth = new DateTime(1980, 6, 15),
                        DateOfJoining = new DateTime(2010, 3, 1),
                        IsActive = true,
                        Created = DateTime.UtcNow,
                        Updated = DateTime.UtcNow
                    },
                    new EmployeeModel
                    {
                        Id = 2,
                        FirstName = "Sneha",
                        LastName = "Patil",
                        Email = "sneha.patil@example.com",
                        Gender = "F",
                        Address = "456 Mumbai Lane, Mumbai, Maharashtra",
                        Designation = "Software Engineer",
                        //DeptId = 2,
                        DateOfBirth = new DateTime(1990, 7, 22),
                        DateOfJoining = new DateTime(2015, 5, 10),
                        IsActive = true,
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 3,
                        FirstName = "Ravi",
                        LastName = "Kale",
                        Email = "ravi.kale@example.com",
                        Gender = "M",
                        Address = "789 Nagpur Street, Nagpur, Maharashtra",
                        Designation = "Finance Analyst",
                        //DeptId = 3,
                        DateOfBirth = new DateTime(1985, 12, 10),
                        DateOfJoining = new DateTime(2018, 11, 1),
                        IsActive = true,
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {   
                        Id = 4,
                        FirstName = "Pooja",
                        LastName = "Shinde",
                        Email = "pooja.shinde@example.com",
                        Gender = "F",
                        Address = "321 Aurangabad Road, Aurangabad, Maharashtra",
                        Designation = "Marketing Executive",
                        //DeptId = 4,
                        DateOfBirth = new DateTime(1992, 3, 5),
                        DateOfJoining = new DateTime(2019, 2, 15),
                        IsActive = true,
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 5,
                        FirstName = "Suresh",
                        LastName = "Gore",
                        Email = "suresh.gore@example.com",
                        Gender = "M",
                        Address = "654 Nashik Lane, Nashik, Maharashtra",
                        Designation = "Operations Manager",
                        //DeptId = 5,
                        DateOfBirth = new DateTime(1978, 9, 28),
                        DateOfJoining = new DateTime(2012, 6, 20),
                        IsActive = true,
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 6,                    
                        FirstName = "Anita",
                        LastName = "Joshi",
                        Email = "anita.joshi@example.com",
                        Gender = "F",
                        Address = "987 Solapur Street, Solapur, Maharashtra",
                        Designation = "HR Specialist",
                        //DeptId = 1,
                        DateOfBirth = new DateTime(1987, 8, 30),
                        DateOfJoining = new DateTime(2016, 4, 5),
                        IsActive = true,
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 7,
                        FirstName = "Ajay",
                        LastName = "Jadhav",
                        Email = "ajay.jadhav@example.com",
                        Gender = "M",
                        Address = "345 Satara Road, Satara, Maharashtra",
                        Designation = "IT Consultant",
                        //DeptId = 2,
                        DateOfBirth = new DateTime(1982, 2, 20),
                        DateOfJoining = new DateTime(2017, 7, 15),
                        IsActive = true,
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 8,
                        FirstName = "Meera",
                        LastName = "Desai",
                        Email = "meera.desai@example.com",
                        Gender = "F",
                        Address = "678 Thane Avenue, Thane, Maharashtra",
                        Designation = "Senior Finance Analyst",
                        //DeptId = 3,
                        DateOfBirth = new DateTime(1991, 10, 10),
                        DateOfJoining = new DateTime(2014, 1, 1),
                        IsActive = true,
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 9,
                        FirstName = "Kunal",
                        LastName = "Naik",
                        Email = "kunal.naik@example.com",
                        Gender = "M",
                        Address = "987 Jalgaon Road, Jalgaon, Maharashtra",
                        Designation = "Marketing Manager",
                        //DeptId = 4,
                        DateOfBirth = new DateTime(1986, 4, 15),
                        DateOfJoining = new DateTime(2011, 8, 25),
                        IsActive = true,
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 10,
                        FirstName = "Prachi",
                        LastName = "Rane",
                        Email = "prachi.rane@example.com",
                        Gender = "F",
                        Address = "321 Pimpri Chinchwad Road, Pimpri Chinchwad, Maharashtra",
                        Designation = "Operations Executive",
                        //DeptId = 5,
                        DateOfBirth = new DateTime(1995, 11, 11),
                        DateOfJoining = new DateTime(2020, 3, 1),
                        IsActive = true,
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					}
                );
        }
    }
}
