﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Command
{
    public class CreateDepartmentCommand : DepartmentCommand { }

    public class CreateDepartmentCommandHandler : IRequestHandler<CreateDepartmentCommand, bool>
    {
        private readonly IGenericRepository<Models.DepartmentModel> _genericRepository;

        public CreateDepartmentCommandHandler(IGenericRepository<Models.DepartmentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(CreateDepartmentCommand request, CancellationToken cancellationToken)
        {
            var departmentModel = new DepartmentModel
            {
                DeptName = request.DeptName,
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow,
            };
            return await _genericRepository.AddAsync(departmentModel);
        }
    }
}
